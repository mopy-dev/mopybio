local EnchantService = {}

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local DataManager = require(ServerScriptService:WaitForChild("DataStoreService"):WaitForChild("DataManager"))
local Toaster = require(ServerScriptService:WaitForChild("Toaster"))
local EnchantConfig = require(ReplicatedStorage:WaitForChild("ClientScripts"):WaitForChild("EnchantConfig"))

local ROLL_INTERVAL_SECONDS = math.max(1, math.floor(tonumber(EnchantConfig.RollIntervalSeconds) or (5 * 60)))
local INITIAL_GOAL = 8
local GOAL_GROWTH = 1.5
local INITIAL_MILESTONE_BONUS = 2

local ATTR_ROLLS = "EnchantRolls"
local ATTR_NEXT_ROLL_IN = "EnchantNextRollIn"
local ATTR_CAN_ROLL = "EnchantCanRoll"
local ATTR_MULT = "EnchantMult"
local ATTR_RAREST = "EnchantRarestCrystal"
local ATTR_TIMES = "EnchantTimes"
local ATTR_GOAL = "EnchantGoal"
local ATTR_PROGRESS_BONUS = "EnchantProgressBonus"
local ATTR_PROMPT_SEEN = "EnchantPromptSeen"
local ATTR_TIP_TOAST_SHOWN = "EnchantTipToastShown"

local started = false
local getStateRemote: RemoteFunction? = nil
local useRollRemote: RemoteFunction? = nil
local markPromptShownRemote: RemoteFunction? = nil

local runtimeProgressSeconds: {[Player]: number} = {}
local rng = Random.new()

local function getOrCreateFolder(parent: Instance, name: string): Folder
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local function getOrCreateRemoteFunction(parent: Instance, name: string): RemoteFunction
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteFunction") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteFunction")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local function getProfile(player: Player)
	local profile = DataManager.Profiles[player]
	if not profile or not profile.Data then
		return nil
	end
	return profile
end

local function ensureCrystalTable(profile)
	local data = profile.Data
	if type(data.EnchantCrystals) ~= "table" then
		data.EnchantCrystals = {}
	end

	for _, crystalName in ipairs(EnchantConfig.Order) do
		local count = math.max(0, math.floor(tonumber(data.EnchantCrystals[crystalName]) or 0))
		data.EnchantCrystals[crystalName] = count
	end

	for key in pairs(data.EnchantCrystals) do
		if EnchantConfig.Crystals[key] == nil then
			data.EnchantCrystals[key] = nil
		end
	end

	return data.EnchantCrystals
end

local function getRarestCrystalName(crystals): string?
	local rarestName = nil
	local rarestRank = -math.huge
	for _, crystalName in ipairs(EnchantConfig.Order) do
		local cfg = EnchantConfig.Crystals[crystalName]
		local count = math.max(0, math.floor(tonumber(crystals[crystalName]) or 0))
		if count > 0 and cfg and tonumber(cfg.rank) and cfg.rank > rarestRank then
			rarestRank = cfg.rank
			rarestName = crystalName
		end
	end
	return rarestName
end

local function computeNextGoal(currentGoal: number): number
	local nextGoal = math.floor((currentGoal * GOAL_GROWTH) + 0.5)
	return math.max(currentGoal + 1, nextGoal)
end

local function ensureProgressData(profile)
	local data = profile.Data
	data.EnchantTimes = math.max(0, math.floor(tonumber(data.EnchantTimes) or 0))
	data.EnchantGoal = math.max(INITIAL_GOAL, math.floor(tonumber(data.EnchantGoal) or INITIAL_GOAL))
	data.EnchantProgressBonus = math.max(0, tonumber(data.EnchantProgressBonus) or 0)
	data.EnchantMilestoneLevel = math.max(0, math.floor(tonumber(data.EnchantMilestoneLevel) or 0))
	data.EnchantPromptSeen = data.EnchantPromptSeen == true
	data.EnchantTipToastShown = data.EnchantTipToastShown == true

	while data.EnchantTimes >= data.EnchantGoal do
		local milestoneBonus = INITIAL_MILESTONE_BONUS + data.EnchantMilestoneLevel
		data.EnchantProgressBonus += milestoneBonus
		data.EnchantMilestoneLevel += 1
		data.EnchantGoal = computeNextGoal(data.EnchantGoal)
	end
end

local function recomputePersistent(profile)
	local data = profile.Data
	data.EnchantRolls = math.max(0, math.floor(tonumber(data.EnchantRolls) or 0))
	ensureProgressData(profile)

	local crystals = ensureCrystalTable(profile)
	local crystalBonus = 0
	for _, crystalName in ipairs(EnchantConfig.Order) do
		local cfg = EnchantConfig.Crystals[crystalName]
		if cfg then
			local count = math.max(0, math.floor(tonumber(crystals[crystalName]) or 0))
			crystalBonus += count * math.max(0, tonumber(cfg.bonus) or 0)
		end
	end

	data.EnchantMult = 1 + crystalBonus + math.max(0, tonumber(data.EnchantProgressBonus) or 0)
	if data.EnchantMult < 1 then
		data.EnchantMult = 1
	end

	return crystals
end

local function buildStateFromProfile(player: Player, profile)
	recomputePersistent(profile)
	local data = profile.Data
	local progress = math.max(0, math.floor(tonumber(runtimeProgressSeconds[player]) or 0))
	local nextRollIn = ROLL_INTERVAL_SECONDS - progress
	if nextRollIn <= 0 then
		nextRollIn = ROLL_INTERVAL_SECONDS
	end

	local rarestName = getRarestCrystalName(data.EnchantCrystals)
	local rarestCfg = rarestName and EnchantConfig.Crystals[rarestName] or nil

	return {
		rolls = data.EnchantRolls,
		nextRollIn = nextRollIn,
		canRoll = data.EnchantRolls > 0,
		enchantMult = tonumber(data.EnchantMult) or 1,
		rarestCrystal = rarestName,
		rarestColor = rarestCfg and rarestCfg.color or nil,
		enchantTimes = math.max(0, math.floor(tonumber(data.EnchantTimes) or 0)),
		enchantGoal = math.max(INITIAL_GOAL, math.floor(tonumber(data.EnchantGoal) or INITIAL_GOAL)),
		enchantProgressBonus = math.max(0, tonumber(data.EnchantProgressBonus) or 0),
		promptSeen = data.EnchantPromptSeen == true,
		tipToastShown = data.EnchantTipToastShown == true,
		serverTime = os.time(),
	}
end

local function applyAttributes(player: Player, state)
	player:SetAttribute(ATTR_ROLLS, math.max(0, math.floor(tonumber(state.rolls) or 0)))
	player:SetAttribute(ATTR_NEXT_ROLL_IN, math.max(0, math.floor(tonumber(state.nextRollIn) or 0)))
	player:SetAttribute(ATTR_CAN_ROLL, state.canRoll == true)
	player:SetAttribute(ATTR_MULT, tonumber(state.enchantMult) or 1)
	player:SetAttribute(ATTR_RAREST, state.rarestCrystal)
	player:SetAttribute(ATTR_TIMES, math.max(0, math.floor(tonumber(state.enchantTimes) or 0)))
	player:SetAttribute(ATTR_GOAL, math.max(INITIAL_GOAL, math.floor(tonumber(state.enchantGoal) or INITIAL_GOAL)))
	player:SetAttribute(ATTR_PROGRESS_BONUS, math.max(0, tonumber(state.enchantProgressBonus) or 0))
	player:SetAttribute(ATTR_PROMPT_SEEN, state.promptSeen == true)
	player:SetAttribute(ATTR_TIP_TOAST_SHOWN, state.tipToastShown == true)
end

local function pickCrystalReward()
	local totalWeight = 0
	for _, crystalName in ipairs(EnchantConfig.Order) do
		local cfg = EnchantConfig.Crystals[crystalName]
		if cfg then
			totalWeight += math.max(0, tonumber(cfg.chance) or 0)
		end
	end

	if totalWeight <= 0 then
		local fallback = EnchantConfig.Crystals.Green
		return {
			name = "Green",
			imageId = fallback and fallback.imageId or "",
			bonus = fallback and fallback.bonus or 0,
			color = fallback and fallback.color or Color3.new(1, 1, 1),
		}
	end

	local roll = rng:NextNumber(0, totalWeight)
	local running = 0
	for _, crystalName in ipairs(EnchantConfig.Order) do
		local cfg = EnchantConfig.Crystals[crystalName]
		if cfg then
			running += math.max(0, tonumber(cfg.chance) or 0)
			if roll <= running then
				return {
					name = crystalName,
					imageId = tostring(cfg.imageId or ""),
					bonus = math.max(0, tonumber(cfg.bonus) or 0),
					color = cfg.color,
				}
			end
		end
	end

	local lastName = EnchantConfig.Order[#EnchantConfig.Order]
	local last = lastName and EnchantConfig.Crystals[lastName]
	return {
		name = lastName or "Green",
		imageId = last and tostring(last.imageId or "") or "",
		bonus = last and math.max(0, tonumber(last.bonus) or 0) or 0,
		color = last and last.color or Color3.new(1, 1, 1),
	}
end

function EnchantService.PushState(player: Player)
	local profile = getProfile(player)
	if not profile then
		local fallbackState = {
			rolls = 0,
			nextRollIn = ROLL_INTERVAL_SECONDS,
			canRoll = false,
			enchantMult = 1,
			rarestCrystal = nil,
			rarestColor = nil,
			enchantTimes = 0,
			enchantGoal = INITIAL_GOAL,
			enchantProgressBonus = 0,
			promptSeen = false,
			tipToastShown = false,
			serverTime = os.time(),
		}
		applyAttributes(player, fallbackState)
		return fallbackState
	end

	local state = buildStateFromProfile(player, profile)
	applyAttributes(player, state)
	return state
end

function EnchantService.GetState(player: Player)
	return EnchantService.PushState(player)
end

function EnchantService.GetMultiplier(player: Player): number
	local profile = getProfile(player)
	if not profile then
		return 1
	end
	recomputePersistent(profile)
	return math.max(1, tonumber(profile.Data.EnchantMult) or 1)
end

function EnchantService.AddRolls(player: Player, amount: number)
	local add = math.max(0, math.floor(tonumber(amount) or 0))
	if add <= 0 then
		return false, EnchantService.PushState(player)
	end

	local profile = getProfile(player)
	if not profile then
		return false, EnchantService.PushState(player)
	end

	recomputePersistent(profile)
	profile.Data.EnchantRolls += add
	local state = EnchantService.PushState(player)
	return true, state
end

function EnchantService.TryConsumeRoll(player: Player, amount: number?)
	local consume = math.max(1, math.floor(tonumber(amount) or 1))
	local profile = getProfile(player)
	if not profile then
		return false, "profile_not_loaded", EnchantService.PushState(player), nil
	end

	recomputePersistent(profile)
	if profile.Data.EnchantRolls < consume then
		return false, "no_rolls", EnchantService.PushState(player), nil
	end

	profile.Data.EnchantRolls -= consume
	profile.Data.EnchantTimes = math.max(0, math.floor(tonumber(profile.Data.EnchantTimes) or 0)) + consume

	local crystals = ensureCrystalTable(profile)
	local rewards = {}
	for _ = 1, consume do
		local reward = pickCrystalReward()
		table.insert(rewards, reward)
		local key = reward.name
		if key and EnchantConfig.Crystals[key] then
			crystals[key] = math.max(0, math.floor(tonumber(crystals[key]) or 0)) + 1
		end
	end

	recomputePersistent(profile)
	local state = EnchantService.PushState(player)

	if profile.Data.EnchantPromptSeen == true and profile.Data.EnchantTipToastShown ~= true then
		profile.Data.EnchantTipToastShown = true
		Toaster.AddToast(player, "You get 1 Enchant every 5 minutes in game!")
		state = EnchantService.PushState(player)
	end

	return true, "rolled", state, rewards
end

local function waitForProfile(player: Player)
	while player.Parent == Players do
		local profile = getProfile(player)
		if profile then
			return profile
		end
		task.wait(0.2)
	end
	return nil
end

local function onPlayerAdded(player: Player)
	runtimeProgressSeconds[player] = 0
	player:SetAttribute(ATTR_ROLLS, 0)
	player:SetAttribute(ATTR_NEXT_ROLL_IN, ROLL_INTERVAL_SECONDS)
	player:SetAttribute(ATTR_CAN_ROLL, false)
	player:SetAttribute(ATTR_MULT, 1)
	player:SetAttribute(ATTR_RAREST, nil)
	player:SetAttribute(ATTR_TIMES, 0)
	player:SetAttribute(ATTR_GOAL, INITIAL_GOAL)
	player:SetAttribute(ATTR_PROGRESS_BONUS, 0)
	player:SetAttribute(ATTR_PROMPT_SEEN, false)
	player:SetAttribute(ATTR_TIP_TOAST_SHOWN, false)
	task.spawn(function()
		local profile = waitForProfile(player)
		if not profile then
			return
		end
		recomputePersistent(profile)
		EnchantService.PushState(player)
	end)
end

local function onPlayerRemoving(player: Player)
	runtimeProgressSeconds[player] = nil
end

local function tickPlayer(player: Player)
	local profile = getProfile(player)
	if not profile then
		EnchantService.PushState(player)
		return
	end

	runtimeProgressSeconds[player] = math.max(0, math.floor(tonumber(runtimeProgressSeconds[player]) or 0)) + 1

	if runtimeProgressSeconds[player] >= ROLL_INTERVAL_SECONDS then
		local gained = math.floor(runtimeProgressSeconds[player] / ROLL_INTERVAL_SECONDS)
		runtimeProgressSeconds[player] = runtimeProgressSeconds[player] % ROLL_INTERVAL_SECONDS
		recomputePersistent(profile)
		profile.Data.EnchantRolls += gained
	end

	EnchantService.PushState(player)
end

function EnchantService.Start()
	if started then
		return
	end
	started = true

	local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
	local enchantingFolder = getOrCreateFolder(remoteEvents, "Enchanting")
	getStateRemote = getOrCreateRemoteFunction(enchantingFolder, "GetState")
	useRollRemote = getOrCreateRemoteFunction(enchantingFolder, "UseRoll")
	markPromptShownRemote = getOrCreateRemoteFunction(enchantingFolder, "MarkPromptShown")

	getStateRemote.OnServerInvoke = function(player: Player)
		if not player or player.Parent ~= Players then
			return {
				rolls = 0,
				nextRollIn = ROLL_INTERVAL_SECONDS,
				canRoll = false,
				enchantMult = 1,
				rarestCrystal = nil,
				rarestColor = nil,
				enchantTimes = 0,
				enchantGoal = INITIAL_GOAL,
				enchantProgressBonus = 0,
				promptSeen = false,
				tipToastShown = false,
				serverTime = os.time(),
			}
		end
		return EnchantService.GetState(player)
	end

	useRollRemote.OnServerInvoke = function(player: Player, amount: number?)
		if not player or player.Parent ~= Players then
			return {
				ok = false,
				code = "invalid_player",
				state = {
					rolls = 0,
					nextRollIn = ROLL_INTERVAL_SECONDS,
					canRoll = false,
					enchantMult = 1,
					rarestCrystal = nil,
					rarestColor = nil,
					enchantTimes = 0,
					enchantGoal = INITIAL_GOAL,
					enchantProgressBonus = 0,
					promptSeen = false,
					tipToastShown = false,
					serverTime = os.time(),
				},
				reward = nil,
				rewards = nil,
			}
		end

		local ok, code, state, rewards = EnchantService.TryConsumeRoll(player, amount)
		local lastReward = (type(rewards) == "table" and rewards[#rewards]) or nil
		return {
			ok = ok,
			code = code,
			state = state,
			reward = lastReward,
			rewards = rewards,
		}
	end

	markPromptShownRemote.OnServerInvoke = function(player: Player)
		if not player or player.Parent ~= Players then
			return false, nil
		end
		local profile = getProfile(player)
		if not profile then
			return false, EnchantService.PushState(player)
		end
		if profile.Data.EnchantPromptSeen ~= true then
			profile.Data.EnchantPromptSeen = true
			Toaster.AddToast(player, "You can enchant to get more speed!")
		end
		local state = EnchantService.PushState(player)
		return true, state
	end

	Players.PlayerAdded:Connect(onPlayerAdded)
	Players.PlayerRemoving:Connect(onPlayerRemoving)
	for _, player in ipairs(Players:GetPlayers()) do
		onPlayerAdded(player)
	end

	task.spawn(function()
		while true do
			task.wait(1)
			for _, player in ipairs(Players:GetPlayers()) do
				tickPlayer(player)
			end
		end
	end)
end

return EnchantService