local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local MarketplaceService = game:GetService("MarketplaceService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer

local Libraries = ReplicatedStorage:WaitForChild("Libraries")
local Abbrev = require(Libraries:WaitForChild("Abbv_Module"))

local RemoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local XPFolder = RemoteEvents:WaitForChild("XPService")
local RebirthFolder = RemoteEvents:WaitForChild("Rebirths")
local CustomSpeedFolder = RemoteEvents:WaitForChild("CustomSpeed")

local PushLevel = XPFolder:WaitForChild("PushLevel")
local PushRebirthInfo = RebirthFolder:WaitForChild("PushRebirthInfo")
local RebirthRemote = RebirthFolder:WaitForChild("Rebirth")
local CloseRebirthUI = RebirthFolder:WaitForChild("CloseRebirthUI")
local MaxSpeedRemote = CustomSpeedFolder:WaitForChild("MaxSpeed")

local SKIP_REBIRTH_PRODUCT_ID = 3556287197

local refs = {}
local activeBarTweens: {[Frame]: Tween} = {}

local popupToken = 0
local popupVisible = false
local popupBaseSize: UDim2? = nil
local popupBaseRotation: number? = nil

local reboundButton: TextButton? = nil
local reboundSkipButton: TextButton? = nil
local boundSpeedTextBox: TextBox? = nil
local lastRebirthClick = 0
local lastSkipClick = 0
local latestAllowedSpeed = 0
local customSetSpeed: number? = nil
local lastKnownSpeed: number? = nil
local SPEED_POPUP_RANGE_SCALE = 0.28
local SPEED_POPUP_MARGIN_SCALE = 0.08

local function findChildByClass(parent: Instance, name: string, className: string)
	for _, child in ipairs(parent:GetChildren()) do
		if child.Name == name and child.ClassName == className then
			return child
		end
	end
	return nil
end

local function scaleUDim2(size: UDim2, mult: number): UDim2
	return UDim2.new(
		size.X.Scale * mult,
		size.X.Offset * mult,
		size.Y.Scale * mult,
		size.Y.Offset * mult
	)
end

local function formatNumber(value: number): string
	local n = math.max(0, math.floor(tonumber(value) or 0))
	local ok, out = pcall(function()
		return Abbrev.abbvNum(n)
	end)
	if ok and out ~= nil then
		return tostring(out)
	end
	return tostring(n)
end

local function formatMult(value: number): string
	local n = tonumber(value) or 1
	local rounded = math.floor(n * 10 + 0.5) / 10
	if math.abs(rounded - math.floor(rounded)) < 1e-5 then
		return tostring(math.floor(rounded))
	end
	return tostring(rounded)
end

local function getPlayerCenterScale(): Vector2
	local camera = Workspace.CurrentCamera
	local character = player.Character
	local rootPart = character and character:FindFirstChild("HumanoidRootPart")
	if not camera or not rootPart or not rootPart:IsA("BasePart") then
		return Vector2.new(0.5, 0.55)
	end

	local viewport = camera.ViewportSize
	if viewport.X <= 0 or viewport.Y <= 0 then
		return Vector2.new(0.5, 0.55)
	end

	local screenPoint, onScreen = camera:WorldToViewportPoint(rootPart.Position + Vector3.new(0, 2.25, 0))
	if not onScreen then
		return Vector2.new(0.5, 0.55)
	end

	return Vector2.new(screenPoint.X / viewport.X, screenPoint.Y / viewport.Y)
end

local function getRandomTargetScale(origin: Vector2, rangeScale: number): Vector2
	local angle = math.random() * math.pi * 2
	local radius = math.sqrt(math.random()) * math.max(0, rangeScale)
	local targetX = origin.X + math.cos(angle) * radius
	local targetY = origin.Y + math.sin(angle) * radius
	return Vector2.new(
		math.clamp(targetX, SPEED_POPUP_MARGIN_SCALE, 1 - SPEED_POPUP_MARGIN_SCALE),
		math.clamp(targetY, SPEED_POPUP_MARGIN_SCALE, 1 - SPEED_POPUP_MARGIN_SCALE)
	)
end

local function playSpeedGainPopup(amount: number)
	if amount <= 0 then
		return
	end

	local mainUI = refs.mainUI
	local template = refs.speedTemplate
	if not (mainUI and mainUI:IsA("ScreenGui") and template and template:IsA("CanvasGroup")) then
		return
	end

	local popup = template:Clone()
	popup.Name = "SpeedGainPopup"
	popup.Visible = true
	popup.Active = false
	popup.AnchorPoint = Vector2.new(0.5, 0.5)
	popup.GroupTransparency = 1

	local textLabel = popup:FindFirstChild("TextLabel")
	if textLabel and textLabel:IsA("TextLabel") then
		textLabel.Text = "+" .. formatNumber(amount)
	end

	local scale = popup:FindFirstChildOfClass("UIScale")
	if not scale then
		scale = Instance.new("UIScale")
		scale.Name = "PopupScale"
		scale.Parent = popup
	end
	scale.Scale = 1.1

	local originScale = getPlayerCenterScale()
	local targetScale = getRandomTargetScale(originScale, SPEED_POPUP_RANGE_SCALE)
	popup.Position = UDim2.new(originScale.X, 0, originScale.Y, 0)
	popup.Parent = mainUI

	local flyIn = TweenService:Create(
		popup,
		TweenInfo.new(0.38, Enum.EasingStyle.Sine, Enum.EasingDirection.Out),
		{
			GroupTransparency = 0,
			Position = UDim2.new(targetScale.X, 0, targetScale.Y, 0),
		}
	)

	local scaleIn = TweenService:Create(
		scale,
		TweenInfo.new(0.38, Enum.EasingStyle.Sine, Enum.EasingDirection.Out),
		{ Scale = 1 }
	)

	local fadeOut = TweenService:Create(
		popup,
		TweenInfo.new(0.34, Enum.EasingStyle.Sine, Enum.EasingDirection.In),
		{ GroupTransparency = 1 }
	)

	local scaleOut = TweenService:Create(
		scale,
		TweenInfo.new(0.34, Enum.EasingStyle.Sine, Enum.EasingDirection.In),
		{ Scale = 0.82 }
	)

	flyIn.Completed:Connect(function(playbackState)
		if playbackState ~= Enum.PlaybackState.Completed or not popup.Parent then
			popup:Destroy()
			return
		end
		task.wait(0.12)
		if not popup.Parent then
			return
		end
		fadeOut:Play()
		scaleOut:Play()
	end)

	fadeOut.Completed:Connect(function()
		if popup.Parent then
			popup:Destroy()
		end
	end)

	flyIn:Play()
	scaleIn:Play()
end

local function normalizeHorizontalFill(fill: Frame, barBackground: Instance?)
	if not fill or not fill:IsA("Frame") then
		return
	end
	if barBackground and barBackground:IsA("Frame") then
		barBackground.ClipsDescendants = true
		if fill.ZIndex <= barBackground.ZIndex then
			fill.ZIndex = barBackground.ZIndex + 1
		end
	end
	fill.Visible = true
	fill.AnchorPoint = Vector2.new(0, 0.5)
	fill.Position = UDim2.new(0, 0, 0.5, 0)
end

local function tweenHorizontalFill(fill: Frame, alpha: number)
	alpha = math.clamp(tonumber(alpha) or 0, 0, 1)
	normalizeHorizontalFill(fill, fill.Parent)

	local currentTween = activeBarTweens[fill]
	if currentTween then
		currentTween:Cancel()
		activeBarTweens[fill] = nil
	end

	local target = UDim2.new(alpha, 0, 1, 0)
	local tween = TweenService:Create(
		fill,
		TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
		{ Size = target }
	)
	activeBarTweens[fill] = tween
	tween:Play()
	tween.Completed:Connect(function()
		if activeBarTweens[fill] == tween then
			activeBarTweens[fill] = nil
		end
	end)
end
local function updateSetSpeedPlaceholder()
	local box = refs.setSpeedTextBox
	if not box or not box:IsA("TextBox") then
		return
	end

	local maxSpeed = math.max(0, latestAllowedSpeed)
	local mode = "MAX"
	local displaySpeed = maxSpeed

	if customSetSpeed ~= nil then
		local parsedCustom = math.max(0, math.floor(tonumber(customSetSpeed) or 0))
		if parsedCustom >= maxSpeed then
			customSetSpeed = nil
		else
			displaySpeed = parsedCustom
			mode = "SET"
		end
	end

	box.PlaceholderText = string.format("%s: %s", mode, formatNumber(displaySpeed))
end

local function updateSetSpeedMaxText()
	if refs.setSpeedMaxText and refs.setSpeedMaxText:IsA("TextLabel") then
		refs.setSpeedMaxText.Text = string.format("MAX: %d", math.max(0, latestAllowedSpeed))
	end
	updateSetSpeedPlaceholder()
end

local function resolveRefs(): boolean
	local playerGui = player:FindFirstChild("PlayerGui") or player:WaitForChild("PlayerGui")
	local mainUI = playerGui:FindFirstChild("MainUI")
	if not mainUI then
		return false
	end

	local botMid = mainUI:FindFirstChild("BotMid")
	local botLevel = botMid and botMid:FindFirstChild("Level")
	local botBarBackground = botLevel and botLevel:FindFirstChild("BarBackground")
	local botFill = botBarBackground and botBarBackground:FindFirstChild("Fill")

	local framesFolder = mainUI:FindFirstChild("Frames")
	local rebirthPanel = framesFolder and framesFolder:FindFirstChild("Rebirth")
	local rebirthActionButton = rebirthPanel and findChildByClass(rebirthPanel, "Rebirth", "TextButton")
	local rebirthProgressFrame = rebirthPanel and findChildByClass(rebirthPanel, "Rebirth", "Frame")
	local rebirthBarBackground = rebirthProgressFrame and rebirthProgressFrame:FindFirstChild("BarBackground")
	local rebirthFill = rebirthBarBackground and rebirthBarBackground:FindFirstChild("Fill")
	local rebirthBarText = rebirthBarBackground and rebirthBarBackground:FindFirstChild("TextLabel")
	local rebirthSkipButton = rebirthPanel and rebirthPanel:FindFirstChild("Skip")

	local rebirthSpeedFrame = rebirthPanel and rebirthPanel:FindFirstChild("Speed")
	local rebirthLevelFrame = rebirthPanel and rebirthPanel:FindFirstChild("Level")

	local speed1 = rebirthSpeedFrame and rebirthSpeedFrame:FindFirstChild("1")
	local speed2 = rebirthSpeedFrame and rebirthSpeedFrame:FindFirstChild("2")
	local level1 = rebirthLevelFrame and rebirthLevelFrame:FindFirstChild("1")
	local level2 = rebirthLevelFrame and rebirthLevelFrame:FindFirstChild("2")

	local leftMid = mainUI:FindFirstChild("LeftMid")
	local buttonsFrame = leftMid and leftMid:FindFirstChild("ButtonsFrame")
	local buttonsInner = buttonsFrame and buttonsFrame:FindFirstChild("Frame")
	local sideRebirthButton = buttonsInner and buttonsInner:FindFirstChild("Rebirth")
	local popup = sideRebirthButton and sideRebirthButton:FindFirstChild("Popup")

	local rightMid = mainUI:FindFirstChild("RightMid")
	local setSpeedFrame = rightMid and rightMid:FindFirstChild("SetSpeed")
	local setSpeedTextBox = setSpeedFrame and setSpeedFrame:FindFirstChild("TextBox")
	local setSpeedMaxText = setSpeedFrame and setSpeedFrame:FindFirstChild("MaxText")
	local templatesFolder = mainUI:FindFirstChild("Templates")
	local speedTemplate = templatesFolder and templatesFolder:FindFirstChild("SpeedTemplate")

	if not (botLevel and botFill and rebirthActionButton and rebirthFill and rebirthBarText and popup) then
		return false
	end

	refs.countLabel = botLevel:FindFirstChild("CountLabel")
	refs.levelLabel = botLevel:FindFirstChild("LevelLabel")
	refs.topText = botLevel:FindFirstChild("TopText")
	refs.botFill = botFill
	refs.botRebirthLabel = botMid and botMid:FindFirstChild("Speed") and botMid.Speed:FindFirstChild("Rebirth")

	refs.rebirthActionButton = rebirthActionButton
	refs.rebirthBarBackground = rebirthBarBackground
	refs.rebirthBarFill = rebirthFill
	refs.rebirthBarText = rebirthBarText
	refs.rebirthSkipButton = rebirthSkipButton

	refs.rebirthSpeed1 = speed1 and speed1:FindFirstChild("TextLabel")
	refs.rebirthSpeed2 = speed2 and speed2:FindFirstChild("TextLabel")
	refs.rebirthLevel1 = level1 and level1:FindFirstChild("TextLabel")
	refs.rebirthLevel2 = level2 and level2:FindFirstChild("TextLabel")

	refs.setSpeedTextBox = setSpeedTextBox
	refs.setSpeedMaxText = setSpeedMaxText
	refs.mainUI = mainUI
	refs.speedTemplate = speedTemplate

	refs.rebirthPopup = popup

	normalizeHorizontalFill(refs.botFill, botBarBackground)
	normalizeHorizontalFill(refs.rebirthBarFill, refs.rebirthBarBackground)

	if refs.rebirthPopup and not popupBaseSize then
		popupBaseSize = refs.rebirthPopup.Size
		popupBaseRotation = refs.rebirthPopup.Rotation
	end

	updateSetSpeedMaxText()
	return true
end

local function setPopupActive(visible: boolean)
	if not resolveRefs() then
		return
	end
	if not refs.rebirthPopup then
		return
	end

	if popupVisible == visible then
		return
	end
	popupVisible = visible
	popupToken += 1
	local token = popupToken
	local popup = refs.rebirthPopup

	popup.Visible = visible
	if not visible then
		if popupBaseSize then
			popup.Size = popupBaseSize
		end
		if popupBaseRotation ~= nil then
			popup.Rotation = popupBaseRotation
		end
		return
	end

	task.spawn(function()
		while token == popupToken and popup.Parent and popup.Visible do
			local baseSize = popupBaseSize or popup.Size
			local baseRot = popupBaseRotation or popup.Rotation

			local t1 = TweenService:Create(
				popup,
				TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut),
				{
					Rotation = baseRot + 10,
					Size = scaleUDim2(baseSize, 1.07),
				}
			)
			t1:Play()
			t1.Completed:Wait()
			if token ~= popupToken then
				break
			end

			local t2 = TweenService:Create(
				popup,
				TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut),
				{
					Rotation = baseRot - 10,
					Size = scaleUDim2(baseSize, 1.03),
				}
			)
			t2:Play()
			t2.Completed:Wait()
			if token ~= popupToken then
				break
			end

			local t3 = TweenService:Create(
				popup,
				TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
				{
					Rotation = baseRot,
					Size = baseSize,
				}
			)
			t3:Play()
			t3.Completed:Wait()
			task.wait(0.08)
		end

		if popup.Parent then
			if popupBaseSize then
				popup.Size = popupBaseSize
			end
			if popupBaseRotation ~= nil then
				popup.Rotation = popupBaseRotation
			end
		end
	end)
end

local function bindRebirthButton()
	if not resolveRefs() then
		return
	end
	local button = refs.rebirthActionButton
	if not button or not button:IsA("TextButton") or button == reboundButton then
		return
	end

	reboundButton = button
	button.Activated:Connect(function()
		local now = os.clock()
		if now - lastRebirthClick < 0.2 then
			return
		end
		lastRebirthClick = now
		RebirthRemote:FireServer()
	end)
end

local function bindSkipButton()
	if not resolveRefs() then
		return
	end
	local button = refs.rebirthSkipButton
	if not button or not button:IsA("TextButton") or button == reboundSkipButton then
		return
	end

	reboundSkipButton = button
	button.Activated:Connect(function()
		local now = os.clock()
		if now - lastSkipClick < 0.2 then
			return
		end
		lastSkipClick = now
		MarketplaceService:PromptProductPurchase(player, SKIP_REBIRTH_PRODUCT_ID)
	end)
end

local function submitCustomSpeed()
	if not resolveRefs() then
		return
	end
	local box = refs.setSpeedTextBox
	if not box or not box:IsA("TextBox") then
		return
	end

	local raw = string.match(box.Text or "", "^%s*(.-)%s*$") or ""
	if raw == "" then
		return
	end

	local parsed = tonumber(raw)
	if parsed ~= nil then
		parsed = math.max(0, math.floor(parsed))
		if latestAllowedSpeed > 0 then
			parsed = math.min(parsed, latestAllowedSpeed)
		end
		if parsed >= math.max(0, latestAllowedSpeed) then
			customSetSpeed = nil
		else
			customSetSpeed = parsed
		end
		updateSetSpeedPlaceholder()
	end

	MaxSpeedRemote:FireServer(raw)
	box.Text = ""
end

local function bindSetSpeedInput()
	if not resolveRefs() then
		return
	end
	local box = refs.setSpeedTextBox
	if not box or not box:IsA("TextBox") or box == boundSpeedTextBox then
		return
	end

	boundSpeedTextBox = box
	box.FocusLost:Connect(function(_enterPressed)
		submitCustomSpeed()
	end)
end

local function bindInteractiveUI()
	bindRebirthButton()
	bindSkipButton()
	bindSetSpeedInput()
end

local function onPushLevel(currentLevel, currentProgress, neededForNext, totalSpeed, isMaxedOut)
	if not resolveRefs() then
		return
	end
	bindInteractiveUI()

	local level = math.max(0, math.floor(tonumber(currentLevel) or 0))
	local progress = math.max(0, math.floor(tonumber(currentProgress) or 0))
	local needed = math.max(1, math.floor(tonumber(neededForNext) or 1))
	local speed = math.max(0, math.floor(tonumber(totalSpeed) or 0))
	if lastKnownSpeed ~= nil then
		local gained = speed - lastKnownSpeed
		if gained > 0 then
			playSpeedGainPopup(gained)
		end
	end
	lastKnownSpeed = speed

	if refs.countLabel and refs.countLabel:IsA("TextLabel") then
		if isMaxedOut then
			refs.countLabel.Text = "MAX"
		else
			refs.countLabel.Text = string.format("%s/%s", formatNumber(progress), formatNumber(needed))
		end
	end

	if refs.levelLabel and refs.levelLabel:IsA("TextLabel") then
		refs.levelLabel.Text = string.format("Level %d", level)
	end

	if refs.topText and refs.topText:IsA("TextLabel") then
		refs.topText.Text = string.format("%s Speed", formatNumber(speed))
	end

	if refs.botFill and refs.botFill:IsA("Frame") then
		local alpha = needed > 0 and (progress / needed) or 0
		if isMaxedOut then
			alpha = 1
		end
		tweenHorizontalFill(refs.botFill, alpha)
	end

	local leaderstats = player:FindFirstChild("leaderstats")
	local speedValue = leaderstats and leaderstats:FindFirstChild("Speed")
	if speedValue and speedValue:IsA("IntValue") then
		speedValue.Value = speed
	end
end

local function onPushRebirthInfo(rebirths, currentLevel, levelCap, nextLevelCap, currentMult, nextMult, canRebirth)
	if not resolveRefs() then
		return
	end
	bindInteractiveUI()

	rebirths = math.max(0, math.floor(tonumber(rebirths) or 0))
	currentLevel = math.max(0, math.floor(tonumber(currentLevel) or 0))
	levelCap = math.max(1, math.floor(tonumber(levelCap) or 1))
	nextLevelCap = math.max(levelCap, math.floor(tonumber(nextLevelCap) or levelCap))
	currentMult = tonumber(currentMult) or 1
	nextMult = tonumber(nextMult) or (currentMult + 0.5)

	if refs.rebirthSpeed1 and refs.rebirthSpeed1:IsA("TextLabel") then
		refs.rebirthSpeed1.Text = string.format("Speed x%s", formatMult(currentMult))
	end
	if refs.rebirthSpeed2 and refs.rebirthSpeed2:IsA("TextLabel") then
		refs.rebirthSpeed2.Text = string.format("Speed x%s", formatMult(nextMult))
	end
	if refs.rebirthLevel1 and refs.rebirthLevel1:IsA("TextLabel") then
		refs.rebirthLevel1.Text = string.format("Max Level %d", levelCap)
	end
	if refs.rebirthLevel2 and refs.rebirthLevel2:IsA("TextLabel") then
		refs.rebirthLevel2.Text = string.format("Max Level %d", nextLevelCap)
	end

	if refs.rebirthBarText and refs.rebirthBarText:IsA("TextLabel") then
		refs.rebirthBarText.Text = string.format("Level %d/%d", currentLevel, levelCap)
	end
	if refs.rebirthBarFill and refs.rebirthBarFill:IsA("Frame") then
		normalizeHorizontalFill(refs.rebirthBarFill, refs.rebirthBarBackground)
		local alpha = math.clamp(currentLevel / levelCap, 0, 1)
		tweenHorizontalFill(refs.rebirthBarFill, alpha)
	end

	if refs.botRebirthLabel and refs.botRebirthLabel:IsA("TextLabel") then
		refs.botRebirthLabel.Text = string.format("x%s Mult (Rebirth)", formatMult(currentMult))
	end

	setPopupActive(canRebirth == true)
end

local function onMaxSpeedChanged(maxAllowedSpeed)
	latestAllowedSpeed = math.max(0, math.floor(tonumber(maxAllowedSpeed) or 0))
	if customSetSpeed ~= nil then
		customSetSpeed = math.max(0, math.floor(tonumber(customSetSpeed) or 0))
		if customSetSpeed >= latestAllowedSpeed then
			customSetSpeed = nil
		end
	end
	if resolveRefs() then
		updateSetSpeedMaxText()
	end
end

local function playLegendaryRebirthSound()
	local playerGui = player:FindFirstChild("PlayerGui")
	if not playerGui then
		return
	end

	local sounds = playerGui:FindFirstChild("Sounds")
	if not sounds then
		return
	end

	local legendary = sounds:FindFirstChild("LegendarySound")
	if legendary and legendary:IsA("Sound") then
		legendary.TimePosition = 0
		legendary:Play()
	end
end

PushLevel.OnClientEvent:Connect(onPushLevel)
PushRebirthInfo.OnClientEvent:Connect(onPushRebirthInfo)
MaxSpeedRemote.OnClientEvent:Connect(onMaxSpeedChanged)

CloseRebirthUI.OnClientEvent:Connect(function()
	setPopupActive(false)
	playLegendaryRebirthSound()
end)

player.CharacterAdded:Connect(function()
	task.wait(0.5)
	resolveRefs()
	bindInteractiveUI()
	updateSetSpeedMaxText()
end)

resolveRefs()
bindInteractiveUI()
updateSetSpeedMaxText()