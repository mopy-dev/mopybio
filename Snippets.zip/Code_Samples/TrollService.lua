local TrollService = {}

local Players = game:GetService("Players")
local Debris = game:GetService("Debris")
local SoundService = game:GetService("SoundService")

local EXCLUDE_PURCHASER_FROM_ALL = true
local NUKE_SOUND_ID = "rbxassetid://92631715509459"

local targetByPlayer = {}

local function isInAfkZone(player)
	return player and player:GetAttribute("InAFKZone") == true
end

local function getCharacter(player)
	return player and player.Character
end

local function getHumanoid(player)
	local character = getCharacter(player)
	if not character then
		return nil
	end
	return character:FindFirstChildOfClass("Humanoid")
end

local function getRootPart(player)
	local character = getCharacter(player)
	if not character then
		return nil
	end
	return character:FindFirstChild("HumanoidRootPart") or character:FindFirstChild("Torso")
end

local function getEligibleTargets(purchaser, includePurchaser)
	local targets = {}
	for _, other in ipairs(Players:GetPlayers()) do
		local allowed = includePurchaser or other ~= purchaser
		if allowed and not isInAfkZone(other) then
			targets[#targets + 1] = other
		end
	end
	table.sort(targets, function(a, b)
		return a.UserId < b.UserId
	end)
	return targets
end

local function forAllTargets(purchaser, handler)
	local includePurchaser = not EXCLUDE_PURCHASER_FROM_ALL
	for _, other in ipairs(getEligibleTargets(purchaser, includePurchaser)) do
		handler(other)
	end
end

local function playNukeSound()
	local sound = Instance.new("Sound")
	sound.SoundId = NUKE_SOUND_ID
	sound.Volume = 1
	sound.RollOffMaxDistance = 100000
	sound.Parent = SoundService
	sound:Play()
	Debris:AddItem(sound, 6)
end

local function nukePlayer(target, blastRadius)
	local rootPart = getRootPart(target)
	if rootPart then
		local explosion = Instance.new("Explosion")
		explosion.BlastPressure = 0
		explosion.BlastRadius = math.max(0, math.floor(tonumber(blastRadius) or 0))
		explosion.DestroyJointRadiusPercent = 0
		explosion.Position = rootPart.Position
		explosion.Parent = workspace
		Debris:AddItem(explosion, 2)
	end
	local humanoid = getHumanoid(target)
	if humanoid then
		humanoid.Health = 0
	end
end

function TrollService.SetTarget(player, targetUserId)
	local userId = tonumber(targetUserId)
	if not userId then
		targetByPlayer[player] = nil
		return
	end
	local target = Players:GetPlayerByUserId(userId)
	if not target or target == player or isInAfkZone(target) then
		targetByPlayer[player] = nil
		return
	end
	targetByPlayer[player] = target.UserId
end

function TrollService.GetTargetPlayer(player)
	local userId = targetByPlayer[player]
	if not userId then
		return nil
	end
	local target = Players:GetPlayerByUserId(userId)
	if not target or isInAfkZone(target) then
		targetByPlayer[player] = nil
		return nil
	end
	return target
end

function TrollService.AutoSelectTarget(player)
	local current = TrollService.GetTargetPlayer(player)
	if current then
		return current
	end
	local target = getEligibleTargets(player, false)[1]
	targetByPlayer[player] = target and target.UserId or nil
	return target
end

function TrollService.KickTarget(purchaser)
	local target = TrollService.GetTargetPlayer(purchaser) or TrollService.AutoSelectTarget(purchaser)
	if target then
		pcall(function()
			target:Kick("Kicked by a troll purchase.")
		end)
	end
end

function TrollService.KickAll(purchaser)
	forAllTargets(purchaser, function(other)
		pcall(function()
			other:Kick("Kicked by a troll purchase.")
		end)
	end)
end

function TrollService.KillTarget(purchaser)
	local target = TrollService.GetTargetPlayer(purchaser) or TrollService.AutoSelectTarget(purchaser)
	local humanoid = target and getHumanoid(target)
	if humanoid then
		humanoid.Health = 0
	end
end

function TrollService.KillAll(purchaser)
	forAllTargets(purchaser, function(other)
		local humanoid = getHumanoid(other)
		if humanoid then
			humanoid.Health = 0
		end
	end)
end

function TrollService.SetFireTarget(purchaser)
	local target = TrollService.GetTargetPlayer(purchaser) or TrollService.AutoSelectTarget(purchaser)
	local humanoid = target and getHumanoid(target)
	local rootPart = target and getRootPart(target)
	if not (humanoid and rootPart) then
		return
	end

	local fire = Instance.new("Fire")
	fire.Size = 10
	fire.Heat = 10
	fire.Parent = rootPart
	Debris:AddItem(fire, 10)

	local startHealth = humanoid.Health
	if startHealth <= 0 then
		return
	end
	local totalDamage = startHealth * (math.random(80, 120) / 100)
	local ticks = 10
	local perTick = totalDamage / ticks

	task.spawn(function()
		for _ = 1, ticks do
			if not humanoid.Parent then
				return
			end
			humanoid:TakeDamage(perTick)
			task.wait(1)
		end
	end)
end

function TrollService.SlowTarget(purchaser)
	local target = TrollService.GetTargetPlayer(purchaser) or TrollService.AutoSelectTarget(purchaser)
	local humanoid = target and getHumanoid(target)
	if not humanoid then
		return
	end

	local originalSpeed = humanoid.WalkSpeed
	humanoid.WalkSpeed = 8

	task.delay(10, function()
		if humanoid.Parent and humanoid.WalkSpeed == 8 then
			humanoid.WalkSpeed = originalSpeed
		end
	end)
end

function TrollService.FlingTarget(purchaser)
	local target = TrollService.GetTargetPlayer(purchaser) or TrollService.AutoSelectTarget(purchaser)
	local humanoid = target and getHumanoid(target)
	local rootPart = target and getRootPart(target)
	if not (humanoid and rootPart) then
		return
	end

	local originalPlatform = humanoid.PlatformStand
	rootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
	rootPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
	humanoid.PlatformStand = true
	rootPart.Anchored = true

	task.delay(0.25, function()
		if not rootPart.Parent then
			return
		end
		rootPart.Anchored = false
		local dir = Vector3.new(math.random(-100, 100), math.random(80, 140), math.random(-100, 100))
		if dir.Magnitude < 1 then
			dir = Vector3.new(0, 120, 0)
		end
		rootPart.AssemblyLinearVelocity = dir.Unit * 250
		rootPart.AssemblyAngularVelocity = Vector3.new(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))

		task.delay(1, function()
			if humanoid.Parent then
				humanoid.PlatformStand = originalPlatform
			end
		end)
	end)
end

function TrollService.NukeTarget(purchaser)
	local target = TrollService.GetTargetPlayer(purchaser) or TrollService.AutoSelectTarget(purchaser)
	if not target then
		return
	end
	playNukeSound()
	nukePlayer(target, 0)
end

function TrollService.NukeAll(purchaser)
	playNukeSound()
	forAllTargets(purchaser, function(other)
		nukePlayer(other, 35)
	end)
end

Players.PlayerRemoving:Connect(function(player)
	targetByPlayer[player] = nil
end)

return TrollService