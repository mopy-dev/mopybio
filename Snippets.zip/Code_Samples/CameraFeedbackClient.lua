local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")
local Lighting = game:GetService("Lighting")

local player = Players.LocalPlayer

local clientScripts = ReplicatedStorage:WaitForChild("ClientScripts")
local FovModule = require(clientScripts:WaitForChild("FovModule"))
local CameraShake = require(clientScripts:WaitForChild("CameraShakeUpdated"))

local remoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local xpFolder = remoteEvents:WaitForChild("XPService")
local rebirthFolder = remoteEvents:WaitForChild("Rebirths")

local pushLevelRemote = xpFolder:WaitForChild("PushLevel")
local closeRebirthUI = rebirthFolder:WaitForChild("CloseRebirthUI")

local purchaseFolder = remoteEvents:FindFirstChild("PurchaseAnnouncer")
if not purchaseFolder then
	purchaseFolder = remoteEvents:WaitForChild("PurchaseAnnouncer", 20)
end

local config = FovModule.DefaultConfig
local shaker = CameraShake.Create(config.CameraShake)

local UI_FOV_ATTR = "UIFovOffset"
local UI_FOV_OFFSET_SMOOTH_SECONDS = 0.12

local currentLevel = config.LevelMin
local hasSeenFirstLevelPacket = false
local moveAlpha = 0
local fovKick = 0
local uiFovOffset = 0
local humanoid: Humanoid? = nil
local rootPart: BasePart? = nil
local charSignals = {}

local renderStepName = "SpeedFeedback_" .. tostring(player.UserId)
local purchaseRemoteConn: RBXScriptConnection? = nil
local purchaseFolderConn: RBXScriptConnection? = nil
local remoteFolderWatchConn: RBXScriptConnection? = nil

local function getSpeedColorEffect()
	local effect = Lighting:FindFirstChild("SpeedColorCorrection")
	if effect and effect:IsA("ColorCorrectionEffect") then
		return effect
	end

	effect = Instance.new("ColorCorrectionEffect")
	effect.Name = "SpeedColorCorrection"
	effect.Brightness = 0
	effect.Contrast = 0
	effect.Saturation = 0
	effect.TintColor = Color3.fromRGB(255, 255, 255)
	effect.Enabled = true
	effect.Parent = Lighting
	return effect
end

local speedColorEffect = getSpeedColorEffect()
if player:GetAttribute(UI_FOV_ATTR) == nil then
	player:SetAttribute(UI_FOV_ATTR, 0)
end

local function disconnectCharSignals()
	for _, conn in ipairs(charSignals) do
		conn:Disconnect()
	end
	table.clear(charSignals)
end

local function bindCharacter(character: Model?)
	disconnectCharSignals()
	humanoid = nil
	rootPart = nil

	if not character then
		return
	end

	humanoid = character:FindFirstChildOfClass("Humanoid")
	rootPart = character:FindFirstChild("HumanoidRootPart")

	table.insert(charSignals, character.ChildAdded:Connect(function(child)
		if child:IsA("Humanoid") then
			humanoid = child
		elseif child:IsA("BasePart") and child.Name == "HumanoidRootPart" then
			rootPart = child
		end
	end))

	table.insert(charSignals, character.ChildRemoved:Connect(function(child)
		if child == humanoid then
			humanoid = nil
		elseif child == rootPart then
			rootPart = nil
		end
	end))
end

local function addKick(kickKey: string)
	local kickCfg = config.Kicks and config.Kicks[kickKey]
	if type(kickCfg) ~= "table" then
		return
	end

	fovKick = math.min(config.Kicks.MaxFovKick or 6, fovKick + (tonumber(kickCfg.fov) or 0))
	shaker:AddImpulse(tonumber(kickCfg.shake) or 0)
end

local function computeMoveTarget(): number
	local dirAlpha = 0
	if humanoid and humanoid.Parent then
		dirAlpha = math.clamp(humanoid.MoveDirection.Magnitude, 0, 1)
	end

	local velAlpha = 0
	if rootPart and rootPart.Parent then
		local speed = rootPart.AssemblyLinearVelocity.Magnitude
		velAlpha = math.clamp((speed - 2) / 26, 0, 1)
	end

	return math.max(dirAlpha, velAlpha)
end

pushLevelRemote.OnClientEvent:Connect(function(level)
	local parsed = math.max(config.LevelMin or 1, math.floor(tonumber(level) or 1))
	if hasSeenFirstLevelPacket and parsed > currentLevel then
		addKick("LevelUp")
	end
	currentLevel = parsed
	hasSeenFirstLevelPacket = true
end)

closeRebirthUI.OnClientEvent:Connect(function()
	addKick("Rebirth")
end)

local function bindPurchaseRemote(remote: Instance?)
	if purchaseRemoteConn then
		purchaseRemoteConn:Disconnect()
		purchaseRemoteConn = nil
	end

	if remote and remote:IsA("RemoteEvent") then
		purchaseRemoteConn = remote.OnClientEvent:Connect(function()
			addKick("Purchase")
		end)
	end
end

local function bindPurchaseFolder(folder: Instance?)
	if purchaseFolderConn then
		purchaseFolderConn:Disconnect()
		purchaseFolderConn = nil
	end

	if not (folder and folder:IsA("Folder")) then
		bindPurchaseRemote(nil)
		return
	end

	bindPurchaseRemote(folder:FindFirstChild("LocalPurchaseSuccess"))
	purchaseFolderConn = folder.ChildAdded:Connect(function(child)
		if child.Name == "LocalPurchaseSuccess" and child:IsA("RemoteEvent") then
			bindPurchaseRemote(child)
		end
	end)
end

bindPurchaseFolder(purchaseFolder)
if remoteFolderWatchConn then
	remoteFolderWatchConn:Disconnect()
	remoteFolderWatchConn = nil
end
remoteFolderWatchConn = remoteEvents.ChildAdded:Connect(function(child)
	if child.Name == "PurchaseAnnouncer" and child:IsA("Folder") then
		purchaseFolder = child
		bindPurchaseFolder(child)
	end
end)
player.CharacterAdded:Connect(function(character)
	bindCharacter(character)
end)

bindCharacter(player.Character)

RunService:UnbindFromRenderStep(renderStepName)
RunService:BindToRenderStep(renderStepName, Enum.RenderPriority.Camera.Value + 1, function(dt)
	local camera = Workspace.CurrentCamera
	if not camera then
		return
	end

	if not humanoid or not rootPart then
		bindCharacter(player.Character)
	end

	local moveTarget = computeMoveTarget()
	local moveSeconds = (moveTarget >= moveAlpha) and (config.Fov.MoveRiseSeconds or 1.4) or (config.Fov.MoveFallSeconds or 0.75)
	moveAlpha = FovModule.StepBySeconds(moveAlpha, moveTarget, dt, moveSeconds)
	local curvedMoveAlpha = FovModule.GetMoveAlpha(moveAlpha, config)

	local inTraining = player:GetAttribute("InAFKZone") == true
	local targetFov, baseShake = FovModule.Compute(currentLevel, curvedMoveAlpha, inTraining, config)

	fovKick = math.max(0, fovKick - ((config.Kicks.FovDecay or 7) * dt))
	targetFov += fovKick

	local targetUiFovOffset = math.clamp(tonumber(player:GetAttribute(UI_FOV_ATTR)) or 0, -40, 40)
	uiFovOffset = FovModule.StepBySeconds(uiFovOffset, targetUiFovOffset, dt, UI_FOV_OFFSET_SMOOTH_SECONDS)
	targetFov += uiFovOffset

	local fovSpeed = (targetFov >= camera.FieldOfView) and config.Fov.RiseSpeed or config.Fov.ReturnSpeed
	camera.FieldOfView = FovModule.StepValue(camera.FieldOfView, targetFov, dt, fovSpeed)

	if not speedColorEffect or not speedColorEffect.Parent then
		speedColorEffect = getSpeedColorEffect()
	end

	local tint, brightness, contrast, saturation = FovModule.ComputeColor(currentLevel, curvedMoveAlpha, inTraining, config)
	local colorSpeed = (config.Color and config.Color.LerpSpeed) or 10
	local colorAlpha = math.clamp(dt * colorSpeed, 0, 1)
	speedColorEffect.TintColor = speedColorEffect.TintColor:Lerp(tint, colorAlpha)
	speedColorEffect.Brightness = FovModule.StepValue(speedColorEffect.Brightness, brightness, dt, colorSpeed)
	speedColorEffect.Contrast = FovModule.StepValue(speedColorEffect.Contrast, contrast, dt, colorSpeed)
	speedColorEffect.Saturation = FovModule.StepValue(speedColorEffect.Saturation, saturation, dt, colorSpeed)

	local offset = shaker:Step(baseShake, dt)
	camera.CFrame *= offset
end)