local Players = game:GetService("Players")
local PhysicsService = game:GetService("PhysicsService")
local Workspace = game:GetService("Workspace")

local GROUP_PLAYER = "Players"
local GROUP_ZOMBIE = "ZombieNPC"
local GROUP_FOG = "Fog"

local function ensureCollisionGroup(name)
	local ok, exists = pcall(function()
		return PhysicsService:IsCollisionGroupRegistered(name)
	end)
	if ok and exists then
		return
	end
	pcall(function()
		PhysicsService:RegisterCollisionGroup(name)
	end)
end

local function setPartGroup(part, groupName)
	if part and part:IsA("BasePart") then
		part.CollisionGroup = groupName
	end
end

local function setModelGroup(model, groupName)
	if not (model and model:IsA("Model")) then
		return
	end
	for _, descendant in ipairs(model:GetDescendants()) do
		if descendant:IsA("BasePart") then
			descendant.CollisionGroup = groupName
		end
	end
end

local function configureCollisionMatrix()
	ensureCollisionGroup(GROUP_PLAYER)
	ensureCollisionGroup(GROUP_ZOMBIE)
	ensureCollisionGroup(GROUP_FOG)

	PhysicsService:CollisionGroupSetCollidable(GROUP_PLAYER, GROUP_FOG, false)
	PhysicsService:CollisionGroupSetCollidable(GROUP_ZOMBIE, GROUP_FOG, true)
	PhysicsService:CollisionGroupSetCollidable(GROUP_PLAYER, GROUP_ZOMBIE, true)
end

local function bindFog()
	local fogFolder = Workspace:FindFirstChild("FogFolder")
	local fog = fogFolder and fogFolder:FindFirstChild("Fog")
	if fog and fog:IsA("BasePart") then
		setPartGroup(fog, GROUP_FOG)
	end
	if fogFolder then
		fogFolder.ChildAdded:Connect(function(child)
			if child.Name == "Fog" and child:IsA("BasePart") then
				setPartGroup(child, GROUP_FOG)
			end
		end)
	end
end

local function bindZombie()
	local zombie = Workspace:FindFirstChild("Zombie")
	if not (zombie and zombie:IsA("Model")) then
		return
	end
	setModelGroup(zombie, GROUP_ZOMBIE)
	zombie.DescendantAdded:Connect(function(descendant)
		if descendant:IsA("BasePart") then
			descendant.CollisionGroup = GROUP_ZOMBIE
		end
	end)
end

local function bindPlayer(player)
	local function onCharacter(character)
		setModelGroup(character, GROUP_PLAYER)
		character.DescendantAdded:Connect(function(descendant)
			if descendant:IsA("BasePart") then
				descendant.CollisionGroup = GROUP_PLAYER
			end
		end)
	end

	if player.Character then
		onCharacter(player.Character)
	end
	player.CharacterAdded:Connect(onCharacter)
end

configureCollisionMatrix()
bindFog()
bindZombie()

for _, player in ipairs(Players:GetPlayers()) do
	bindPlayer(player)
end
Players.PlayerAdded:Connect(bindPlayer)
