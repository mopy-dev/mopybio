local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")
local TextChatService = game:GetService("TextChatService")

local remoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local purchaseFolder = remoteEvents:WaitForChild("PurchaseAnnouncer")
local announceRemote = purchaseFolder:WaitForChild("GlobalPurchaseAnnounce")

local function postSystemMessage(text: string)
	if TextChatService.ChatVersion == Enum.ChatVersion.TextChatService then
		local channel = TextChatService:FindFirstChild("TextChannels")
			and TextChatService.TextChannels:FindFirstChild("RBXGeneral")
		if channel then
			channel:DisplaySystemMessage(text)
			return
		end
	end

	pcall(function()
		StarterGui:SetCore("ChatMakeSystemMessage", {
			Text = text,
		})
	end)
end

announceRemote.OnClientEvent:Connect(function(message: any)
	if typeof(message) == "string" and #message > 0 then
		postSystemMessage(message)
	end
end)