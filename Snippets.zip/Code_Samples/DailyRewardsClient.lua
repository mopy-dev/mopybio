local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer

local UIHandler = require(ReplicatedStorage:WaitForChild("ClientScripts"):WaitForChild("UI"):WaitForChild("UIHandler"))

local remoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local dailyFolder = remoteEvents:WaitForChild("DailyRewards")

local getStateRemote = dailyFolder:WaitForChild("GetState")
local claimDayRemote = dailyFolder:WaitForChild("ClaimDay")

local refs = {
	frame = nil,
	days = {},
}

local wiggleTweens = {}
local baseRotations = {}
local boundButtons = {}
local timerLabelDefaultColors = setmetatable({}, { __mode = "k" })
local CLAIM_READY_COLOR = Color3.fromRGB(120, 255, 120)
local state = nil
local stateReceivedAt = 0

local requestInFlight = false
local clickDebounceAt = 0
local initialCharacterReady = false
local autoOpenDone = false
local queuedTutorialOpen = false
local tutorialOpenAt = 0
local currentWins = 0
local function clampDay(day: number): number
	day = math.floor(tonumber(day) or 1)
	if day < 1 then
		return 1
	end
	if day > 7 then
		return 7
	end
	return day
end

local function formatHHMMSS(totalSeconds: number): string
	totalSeconds = math.max(0, math.floor(tonumber(totalSeconds) or 0))
	local hours = math.floor(totalSeconds / 3600)
	local minutes = math.floor((totalSeconds % 3600) / 60)
	local seconds = totalSeconds % 60
	return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end

local function stopWiggle(image: GuiObject)
	local activeTween = wiggleTweens[image]
	if activeTween then
		activeTween:Cancel()
		wiggleTweens[image] = nil
	end
	local baseRotation = baseRotations[image]
	if baseRotation ~= nil then
		image.Rotation = baseRotation
	end
end

local function startWiggle(image: GuiObject)
	if wiggleTweens[image] then
		return
	end
	if baseRotations[image] == nil then
		baseRotations[image] = image.Rotation
	end

	local baseRotation = baseRotations[image] or 0
	image.Rotation = baseRotation

	local tween = TweenService:Create(
		image,
		TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
		{ Rotation = baseRotation + 10 }
	)
	wiggleTweens[image] = tween
	tween:Play()
end

local function stopAllWiggles()
	for image in pairs(wiggleTweens) do
		if image and image.Parent then
			stopWiggle(image)
		end
	end
end

local function resolveRefs(): boolean
	local playerGui = player:FindFirstChild("PlayerGui") or player:WaitForChild("PlayerGui")
	local mainUI = playerGui:FindFirstChild("MainUI")
	if not mainUI then
		return false
	end

	local frames = mainUI:FindFirstChild("Frames")
	if not frames then
		return false
	end

	local frame = frames:FindFirstChild("DailyReward")
	if not (frame and frame:IsA("Frame")) then
		return false
	end

	refs.frame = frame
	refs.days = {}

	for day = 1, 7 do
		local dayFrame = frame:FindFirstChild("Day" .. tostring(day))
		if dayFrame and dayFrame:IsA("ImageButton") then
			local rewardImage = dayFrame:FindFirstChild("RewardImage")
			local rewardLabel = dayFrame:FindFirstChild("RewardLabel")
			local timerLabel = dayFrame:FindFirstChild("TimerLabel")
			local tick = dayFrame:FindFirstChild("Tick")
			local rays = dayFrame:FindFirstChild("Rays")

			if timerLabel and timerLabel:IsA("TextLabel") and not timerLabelDefaultColors[timerLabel] then
				timerLabelDefaultColors[timerLabel] = timerLabel.TextColor3
			end

			if rewardImage and rewardImage:IsA("GuiObject") and baseRotations[rewardImage] == nil then
				baseRotations[rewardImage] = rewardImage.Rotation
			end

			if rays and rays:IsA("GuiObject") then
				rays.Visible = false
			end

			refs.days[day] = {
				frame = dayFrame,
				rewardImage = rewardImage,
				rewardLabel = rewardLabel,
				timerLabel = timerLabel,
				tick = tick,
				rays = rays,
			}
		end
	end

	return true
end

local function applyState(payload)
	if type(payload) ~= "table" then
		return
	end

	state = {
		currentDay = clampDay(payload.currentDay),
		pendingClaims = math.max(0, math.floor(tonumber(payload.pendingClaims) or 0)),
		secondsToNext = math.max(0, math.floor(tonumber(payload.secondsToNext) or 0)),
		wins = math.max(0, math.floor(tonumber(payload.wins) or 0)),
		tutorialCompleted = payload.tutorialCompleted == true,
		firstPlaySession = payload.firstPlaySession == true,
		days = type(payload.days) == "table" and payload.days or {},
	}
	currentWins = math.max(currentWins, state.wins)
	stateReceivedAt = os.clock()
end

local function getDayRemainingSeconds(dayData): number
	local rawSeconds = 0
	if type(dayData) == "table" then
		rawSeconds = math.max(0, math.floor(tonumber(dayData.secondsToReady) or 0))
	end
	local elapsed = os.clock() - stateReceivedAt
	return math.max(0, math.floor(rawSeconds - elapsed + 0.5))
end

local function updateVisuals()
	if not resolveRefs() then
		stopAllWiggles()
		return
	end

	if not state then
		stopAllWiggles()
		return
	end

	for day = 1, 7 do
		local ref = refs.days[day]
		if ref then
			local dayData = state.days[day]
			if type(dayData) ~= "table" then
				dayData = {}
			end

			local claimed = dayData.claimed == true
			local ready = dayData.ready == true
			local remaining = getDayRemainingSeconds(dayData)

			if ref.rewardLabel and ref.rewardLabel:IsA("TextLabel") then
				ref.rewardLabel.Text = tostring(dayData.description or "")
			end

			if ref.rewardImage and ref.rewardImage:IsA("ImageButton") then
				ref.rewardImage.Image = tostring(dayData.imageId or "")
			end

			if ref.rays and ref.rays:IsA("GuiObject") then
				ref.rays.Visible = dayData.showRays == true
			end

			if ref.tick and ref.tick:IsA("GuiObject") then
				ref.tick.Visible = claimed
			end

			if ref.timerLabel and ref.timerLabel:IsA("TextLabel") then
				local defaultColor = timerLabelDefaultColors[ref.timerLabel] or ref.timerLabel.TextColor3
				if claimed then
					ref.timerLabel.Text = "CLAIMED"
					ref.timerLabel.TextColor3 = defaultColor
				elseif ready then
					ref.timerLabel.Text = "CLAIM!"
					ref.timerLabel.TextColor3 = CLAIM_READY_COLOR
				else
					ref.timerLabel.Text = formatHHMMSS(remaining)
					ref.timerLabel.TextColor3 = defaultColor
				end
			end

			if ref.rewardImage and ref.rewardImage:IsA("GuiObject") then
				if ready then
					startWiggle(ref.rewardImage)
				else
					stopWiggle(ref.rewardImage)
				end
			end
		end
	end
end

local function requestState(): boolean
	if requestInFlight then
		return false
	end
	requestInFlight = true

	local ok, payload = pcall(function()
		return getStateRemote:InvokeServer()
	end)

	requestInFlight = false

	if not ok or type(payload) ~= "table" then
		return false
	end

	applyState(payload)
	updateVisuals()
	return true
end

local function requestClaim(day: number)
	local now = os.clock()
	if now - clickDebounceAt < 0.15 then
		return
	end
	clickDebounceAt = now

	local ok, response = pcall(function()
		return claimDayRemote:InvokeServer(day)
	end)
	if not ok or type(response) ~= "table" then
		return
	end

	if type(response.state) == "table" then
		applyState(response.state)
		updateVisuals()
	else
		requestState()
	end

	if response.ok == true and response.code == "claimed" and resolveRefs() then
		UIHandler:CloseFrame(refs.frame)
	end
end

local function bindButtons()
	if not resolveRefs() then
		return
	end

	for day = 1, 7 do
		local ref = refs.days[day]
		if ref then
			local dayFrame = ref.frame
			if dayFrame and dayFrame:IsA("GuiButton") and not boundButtons[dayFrame] then
				boundButtons[dayFrame] = true
				dayFrame.Activated:Connect(function()
					requestClaim(day)
				end)
			end

			local rewardImage = ref.rewardImage
			if rewardImage and rewardImage:IsA("GuiButton") and not boundButtons[rewardImage] then
				boundButtons[rewardImage] = true
				rewardImage.Activated:Connect(function()
					requestClaim(day)
				end)
			end
		end
	end
end
local function tryAutoOpenDaily()
	if autoOpenDone or not initialCharacterReady or not state then
		return
	end

	local tutorialDone = state.tutorialCompleted or player:GetAttribute("TutorialCompleted") == true
	if not tutorialDone then
		queuedTutorialOpen = true
		tutorialOpenAt = 0
		return
	end

	if state.firstPlaySession and currentWins <= 0 then
		return
	end

	if queuedTutorialOpen then
		if tutorialOpenAt <= 0 then
			tutorialOpenAt = os.clock() + 3
			return
		end
		if os.clock() < tutorialOpenAt then
			return
		end
	end

	if resolveRefs() then
		UIHandler:OpenFrame(refs.frame)
		autoOpenDone = true
		queuedTutorialOpen = false
		tutorialOpenAt = 0
	end
end

player:GetAttributeChangedSignal("TutorialCompleted"):Connect(function()
	if autoOpenDone then
		return
	end
	if player:GetAttribute("TutorialCompleted") == true then
		tryAutoOpenDaily()
	end
end)

task.spawn(function()
	local character = player.Character or player.CharacterAdded:Wait()
	if character and not character:FindFirstChild("HumanoidRootPart") then
		character:WaitForChild("HumanoidRootPart", 5)
	end
	initialCharacterReady = true
	tryAutoOpenDaily()
end)


task.spawn(function()
	local leaderstats = player:FindFirstChild("leaderstats") or player:WaitForChild("leaderstats")
	local winsValue = leaderstats:FindFirstChild("Wins")
	if not (winsValue and winsValue:IsA("IntValue")) then
		return
	end

	currentWins = math.max(currentWins, math.floor(tonumber(winsValue.Value) or 0))
	winsValue.Changed:Connect(function(value)
		currentWins = math.max(0, math.floor(tonumber(value) or 0))
		if not autoOpenDone and currentWins > 0 then
			requestState()
			tryAutoOpenDaily()
		end
	end)
end)

bindButtons()

while not requestState() do
	task.wait(0.35)
end

tryAutoOpenDaily()

task.spawn(function()
	while true do
		bindButtons()
		updateVisuals()
		tryAutoOpenDaily()
		task.wait(0.2)
	end
end)