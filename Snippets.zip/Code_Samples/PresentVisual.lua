local RunService = game:GetService("RunService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local remoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local spawnPresentRemote = remoteEvents:WaitForChild("SpawnPresent")
local presentTemplate = ReplicatedStorage:WaitForChild("Stuff"):WaitForChild("Present")

local function getDropsFolder()
	return Workspace:WaitForChild("PresentDrops", 10)
end

local function getPrimaryPart(model)
	if model.PrimaryPart and model.PrimaryPart:IsA("BasePart") then
		return model.PrimaryPart
	end
	local firstPart = model:FindFirstChildWhichIsA("BasePart", true)
	if firstPart then
		model.PrimaryPart = firstPart
		return firstPart
	end
	return nil
end

local function tryPlaySound(model, soundName)
	local sound = model:FindFirstChild(soundName, true)
	if sound and sound:IsA("Sound") then
		sound:Play()
	end
end

local function waitForDropPart(dropName)
	local folder = getDropsFolder()
	if not folder then
		return nil
	end

	local deadline = os.clock() + 4
	local dropPart = folder:FindFirstChild(dropName)
	while not dropPart and os.clock() < deadline do
		task.wait(0.1)
		dropPart = folder:FindFirstChild(dropName)
	end

	if dropPart and dropPart:IsA("BasePart") then
		return dropPart
	end
	return nil
end

spawnPresentRemote.OnClientEvent:Connect(function(endPos, dropName)
	if typeof(endPos) ~= "Vector3" or type(dropName) ~= "string" then
		return
	end

	local character = player.Character or player.CharacterAdded:Wait()
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root or not root:IsA("BasePart") then
		return
	end

	local present = presentTemplate:Clone()
	present.Parent = Workspace

	local primary = getPrimaryPart(present)
	if not primary then
		present:Destroy()
		return
	end

	present:ScaleTo(0.45)

	local startPos = root.Position + Vector3.new(0, 2, 0)
	local midPos = (startPos + endPos) / 2 + Vector3.new(0, 6, 0)
	present:PivotTo(CFrame.new(startPos))

	tryPlaySound(present, "Pop")
	tryPlaySound(present, "Throw")
	tryPlaySound(present, "shine sprite loop")

	local hovering = false
	local hoverTime = 0
	local launchTime = 0
	local launchDuration = 0.45

	local connection
	connection = RunService.RenderStepped:Connect(function(dt)
		if not present.Parent then
			connection:Disconnect()
			return
		end

		if not hovering then
			launchTime += dt
			local alpha = math.clamp(launchTime / launchDuration, 0, 1)
			local a = startPos:Lerp(midPos, alpha)
			local b = midPos:Lerp(endPos, alpha)
			local position = a:Lerp(b, alpha)
			present:PivotTo(CFrame.new(position))
			if alpha >= 1 then
				hovering = true
				tryPlaySound(present, "Ground")
				tryPlaySound(present, "Shine Sound")
			end
		else
			hoverTime += dt
			local offset = math.sin(hoverTime * 2.5) * 0.4
			local spin = CFrame.Angles(0, hoverTime * 1.6, 0)
			present:PivotTo(CFrame.new(endPos + Vector3.new(0, 2 + offset, 0)) * spin)
		end
	end)

	local dropPart = waitForDropPart(dropName)
	if not dropPart then
		if connection then
			connection:Disconnect()
		end
		present:Destroy()
		return
	end

	dropPart.Destroying:Connect(function()
		if connection then
			connection:Disconnect()
		end

		tryPlaySound(present, "Throw2")
		tryPlaySound(present, "Pop")

		local collectTime = 0
		local collectDuration = 0.3
		local collectConnection
		collectConnection = RunService.RenderStepped:Connect(function(dt)
			if not present.Parent then
				collectConnection:Disconnect()
				return
			end

			collectTime += dt
			local alpha = math.clamp(collectTime / collectDuration, 0, 1)
			local currentCharacter = player.Character
			local currentRoot = currentCharacter and currentCharacter:FindFirstChild("HumanoidRootPart")
			local targetPos = currentRoot and currentRoot.Position or endPos
			local movePos = endPos:Lerp(targetPos, alpha)

			present:ScaleTo(math.max(0.45 * (1 - alpha), 0.05))
			present:PivotTo(CFrame.new(movePos))

			if alpha >= 1 then
				collectConnection:Disconnect()
				present:Destroy()
			end
		end)
	end)
end)