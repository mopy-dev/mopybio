local XPService = {}

-- XP growth config
local GROWTH_RATE = 1.15
local BASE_XP = 20

-- Level cap config
local LEVEL_CAP_BASE = 20
local LEVEL_CAP_PER_REBIRTH = 15

-- Rebirth speed multiplier preview config
local REBIRTH_SPEED_MULT_BASE = 1
local REBIRTH_SPEED_MULT_STEP = 0.5

-- Safety for XPToLevel search
local MAX_LEVEL_SEARCH = 5000

-- Caches total XP required to reach each level
local _totalXPByLevel = { [0] = 0 }
local _highestCachedLevel = 0

local XPRemFolder = game.ReplicatedStorage.RemoteEvents:WaitForChild("XPService")
local AddXP = XPRemFolder:WaitForChild("AddXP")

local function deltaXPForLevel(level: number): number
	if level <= 0 then
		return 0
	end
	local raw = BASE_XP * (GROWTH_RATE ^ (level - 1))
	return math.max(1, math.floor(raw))
end

local function ensureCachedUpTo(level: number)
	if level <= _highestCachedLevel then
		return
	end

	level = math.min(level, MAX_LEVEL_SEARCH)
	for lv = _highestCachedLevel + 1, level do
		_totalXPByLevel[lv] = _totalXPByLevel[lv - 1] + deltaXPForLevel(lv)
	end
	_highestCachedLevel = level
end

function XPService.LevelToXP(level: number): number
	level = math.max(0, math.floor(level))
	ensureCachedUpTo(level)
	return _totalXPByLevel[level] or 0
end

function XPService.XPToLevel(totalXP: number): number
	totalXP = math.max(0, math.floor(totalXP))
	if totalXP <= 0 then
		return 0
	end

	while _highestCachedLevel < MAX_LEVEL_SEARCH and XPService.LevelToXP(_highestCachedLevel) < totalXP do
		ensureCachedUpTo(math.min(MAX_LEVEL_SEARCH, math.max(_highestCachedLevel + 50, _highestCachedLevel * 2)))
	end

	local lo, hi = 0, _highestCachedLevel
	while lo < hi do
		local mid = math.ceil((lo + hi) / 2)
		if XPService.LevelToXP(mid) <= totalXP then
			lo = mid
		else
			hi = mid - 1
		end
	end

	return lo
end

function XPService.GetLevelCap(rebirth: number): number
	rebirth = tonumber(rebirth) or 0
	return LEVEL_CAP_BASE + rebirth * LEVEL_CAP_PER_REBIRTH
end

function XPService.GetRebirthSpeedMult(rebirth: number): number
	rebirth = tonumber(rebirth) or 0
	if rebirth < 0 then
		rebirth = 0
	end
	return REBIRTH_SPEED_MULT_BASE + (rebirth * REBIRTH_SPEED_MULT_STEP)
end

function XPService.GetProgressInfo(totalXP: number, rebirth: number)
	totalXP = math.max(0, math.floor(tonumber(totalXP) or 0))
	rebirth = tonumber(rebirth) or 0

	local levelCap = XPService.GetLevelCap(rebirth)
	local maxXP = XPService.LevelToXP(levelCap)
	local clampedXP = math.min(totalXP, maxXP)

	local currentLevel = XPService.XPToLevel(clampedXP)
	if currentLevel > levelCap then
		currentLevel = levelCap
	end

	local currentLevelStartXP = XPService.LevelToXP(currentLevel)
	local nextLevelTotalXP
	if currentLevel >= levelCap then
		nextLevelTotalXP = maxXP
	else
		nextLevelTotalXP = XPService.LevelToXP(currentLevel + 1)
	end

	local progressInLevel = math.max(0, clampedXP - currentLevelStartXP)
	local totalNeededForNext = math.max(1, nextLevelTotalXP - currentLevelStartXP)
	local atCap = currentLevel >= levelCap and clampedXP >= maxXP
	if atCap then
		progressInLevel = totalNeededForNext
	end

	return {
		totalXP = totalXP,
		clampedXP = clampedXP,
		levelCap = levelCap,
		maxXP = maxXP,
		currentLevel = currentLevel,
		progressInLevel = progressInLevel,
		totalNeededForNext = totalNeededForNext,
		atCap = atCap,
	}
end

function XPService.CanRebirth(totalXP: number, rebirth: number): boolean
	local info = XPService.GetProgressInfo(totalXP, rebirth)
	return info.currentLevel >= info.levelCap
end

function XPService.AddXPVisuals(player: Player, amt: number, source: string?)
	if not amt then
		return
	end
	--AddXP:FireClient(player, math.ceil(tonumber(amt) or 0), source)
end

return XPService