local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MessagingService = game:GetService("MessagingService")
local MarketplaceService = game:GetService("MarketplaceService")
local HttpService = game:GetService("HttpService")

local Toaster = require(game.ServerScriptService:WaitForChild("Toaster"))
local SpeedEngine = require(game.ServerScriptService:WaitForChild("SpeedEngine"))

local PurchaseAnnouncer = {}

local TOPIC_NAME = "GlobalPurchaseAnnounce_v3"
local ROBUX_SYMBOL = ""
local PRODUCT_CACHE_TTL = 600

local function getOrCreateFolder(parent: Instance, name: string): Folder
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local function getOrCreateRemoteEvent(parent: Instance, name: string): RemoteEvent
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteEvent") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local function getPurchaseFolder(): Folder
	local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
	return getOrCreateFolder(remoteEvents, "PurchaseAnnouncer")
end

local function getGlobalRemote(): RemoteEvent
	local announcerFolder = getPurchaseFolder()
	return getOrCreateRemoteEvent(announcerFolder, "GlobalPurchaseAnnounce")
end

local function getLocalPurchaseRemote(): RemoteEvent
	local announcerFolder = getPurchaseFolder()
	return getOrCreateRemoteEvent(announcerFolder, "LocalPurchaseSuccess")
end

local function getConfettiRemote(): RemoteEvent
	local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
	local uiFolder = getOrCreateFolder(remoteEvents, "UI")
	return getOrCreateRemoteEvent(uiFolder, "Confetti")
end

local globalRemote = getGlobalRemote()
local localPurchaseRemote = getLocalPurchaseRemote()
local confettiRemote = getConfettiRemote()
local infoCache: {[string]: {name: string, price: number, at: number}} = {}

local function makeCacheKey(infoType: Enum.InfoType, id: number): string
	return tostring(infoType.Value) .. ":" .. tostring(id)
end

local function fetchProductInfo(infoType: Enum.InfoType, id: number): (string, number)
	local key = makeCacheKey(infoType, id)
	local now = os.time()
	local cached = infoCache[key]
	if cached and (now - cached.at) <= PRODUCT_CACHE_TTL then
		return cached.name, cached.price
	end

	local ok, info = pcall(function()
		return MarketplaceService:GetProductInfo(id, infoType)
	end)

	if not ok or type(info) ~= "table" then
		return "Item " .. tostring(id), 0
	end

	local name = tostring(info.Name or ("Item " .. tostring(id)))
	local price = tonumber(info.PriceInRobux) or 0
	infoCache[key] = {
		name = name,
		price = price,
		at = now,
	}
	return name, price
end

local function formatMessage(playerName: string, itemName: string, price: number): string
	return string.format("%s has purchased %s for %s%d!", playerName, itemName, ROBUX_SYMBOL, price)
end

local function displayHere(message: string)
	globalRemote = getGlobalRemote()
	globalRemote:FireAllClients(message)
end

local function publishGlobal(message: string)
	local payload = HttpService:JSONEncode({
		v = 1,
		message = message,
		t = os.time(),
	})

	local ok, err = pcall(function()
		MessagingService:PublishAsync(TOPIC_NAME, payload)
	end)
	if not ok then
		warn("[PurchaseAnnouncer] PublishAsync failed:", err)
	end
end

local initialized = false

function PurchaseAnnouncer.Init()
	if initialized then
		return
	end
	initialized = true

	globalRemote = getGlobalRemote()
	localPurchaseRemote = getLocalPurchaseRemote()

	local ok, err = pcall(function()
		MessagingService:SubscribeAsync(TOPIC_NAME, function(msg)
			if typeof(msg) ~= "table" or type(msg.Data) ~= "string" then
				return
			end
			local decodedOk, data = pcall(function()
				return HttpService:JSONDecode(msg.Data)
			end)
			if not decodedOk or type(data) ~= "table" then
				return
			end
			if type(data.message) == "string" and data.message ~= "" then
				displayHere(data.message)
			end
		end)
	end)

	if not ok then
		warn("[PurchaseAnnouncer] SubscribeAsync failed:", err)
	end
	Players.PlayerAdded:Connect(function()
		globalRemote = getGlobalRemote()
		localPurchaseRemote = getLocalPurchaseRemote()
	end)
end

function PurchaseAnnouncer.AnnounceGamepassPurchase(player: Player, gamepassId: number)
	local itemName, price = fetchProductInfo(Enum.InfoType.GamePass, gamepassId)
	local message = formatMessage(player.Name, itemName, price)
	--displayHere(message)
	publishGlobal(message)
	localPurchaseRemote = getLocalPurchaseRemote()
	localPurchaseRemote:FireClient(player)
end

function PurchaseAnnouncer.AnnounceDevProductPurchase(player: Player, productId: number)
	local itemName, price = fetchProductInfo(Enum.InfoType.Product, productId)
	local message = formatMessage(player.Name, itemName, price)
	--displayHere(message)
	publishGlobal(message)
	localPurchaseRemote = getLocalPurchaseRemote()
	localPurchaseRemote:FireClient(player)
end

function PurchaseAnnouncer.CelebratePurchase(player: Player)
	if not player or player.Parent ~= Players then
		return
	end

	Toaster.AddToast(player, "Thanks for your purchase!", Color3.fromRGB(100, 255, 100))
	SpeedEngine.ApplyTemporarySpeedBoost(player, 2, 5)

	task.spawn(function()
		for i = 1, 5 do
			if player.Parent ~= Players then
				break
			end
			confettiRemote = getConfettiRemote()
			confettiRemote:FireClient(player, { silent = i > 1 })
			if i < 5 then
				task.wait(1)
			end
		end
	end)
end

return PurchaseAnnouncer