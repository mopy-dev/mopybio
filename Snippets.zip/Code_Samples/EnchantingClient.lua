local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local Debris = game:GetService("Debris")

local player = Players.LocalPlayer

local UIHandler = require(ReplicatedStorage:WaitForChild("ClientScripts"):WaitForChild("UI"):WaitForChild("UIHandler"))
local OrbService = require(ReplicatedStorage:WaitForChild("ClientScripts"):WaitForChild("OrbService"))
local MakeBeams = require(ReplicatedStorage:WaitForChild("ClientScripts"):WaitForChild("MakeBeams"))
local EnchantConfig = require(ReplicatedStorage:WaitForChild("ClientScripts"):WaitForChild("EnchantConfig"))

local remoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local mapZonesFolder = remoteEvents:WaitForChild("MapZones")
local enchantingFolder = remoteEvents:WaitForChild("Enchanting")

local openEnchantingRemote = mapZonesFolder:WaitForChild("OpenEnchanting")
local getStateRemote = enchantingFolder:WaitForChild("GetState")
local useRollRemote = enchantingFolder:WaitForChild("UseRoll")
local markPromptShownRemote = enchantingFolder:WaitForChild("MarkPromptShown")
local BUY_1_PRODUCT_ID = 3559032919
local BUY_3_PRODUCT_ID = 3559032999
local BUY_10_PRODUCT_ID = 3559033120

local READY_COLOR = Color3.fromRGB(0, 255, 0)
local HIDDEN_OFFSET = Vector3.new(0, -200, 0)
local OPENING_TIME_SCALE = 1
local BLADE_MODEL_NAME = "EquippedUnlockBlade"
local ENCHANT_CRATE_IMAGE = tostring(EnchantConfig.CrateImageId or "rbxassetid://90567982230154")
local refs = {}
local refs = {}
local state = {
	rolls = 0,
	nextRollIn = 5 * 60,
	canRoll = false,
	enchantMult = 1,
	enchantTimes = 0,
	enchantGoal = 8,
	enchantProgressBonus = 0,
	promptSeen = false,
	serverTime = os.time(),
}
local stateAppliedAt = os.clock()
local attentionAcknowledged = false
local mainAttentionVisible = false
local revealInProgress = false
local suppressOpenUntil = 0
local guideBeam = nil
local guideTargetPart: BasePart? = nil
local guideShown = false
local guideMarked = false

local worldHidden = false
local tableOriginalPivot: CFrame? = nil
local zoneOriginalCFrame: CFrame? = nil
local bookBasePivot: CFrame? = nil
local bookBaseRelative: CFrame? = nil
local timerLabelDefaultColor: Color3? = nil
local bound = {
	mainButton = nil,
	enchantButton = nil,
	buy1 = nil,
	buy3 = nil,
	buy10 = nil,
}
local mainButtonBaseSize: UDim2? = nil
local mainButtonBaseRotation: number? = nil
local goalBaseRotation: number? = nil
local function formatMMSS(seconds: number): string
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	local mm = math.floor(seconds / 60)
	local ss = seconds % 60
	return string.format("%02d:%02d", mm, ss)
end

local function scaleUDim2(size: UDim2, multiplier: number): UDim2
	return UDim2.new(
		size.X.Scale * multiplier,
		size.X.Offset * multiplier,
		size.Y.Scale * multiplier,
		size.Y.Offset * multiplier
	)
end

local function getEstimatedNextRollIn(): number
	local elapsed = os.clock() - stateAppliedAt
	local remaining = math.floor((tonumber(state.nextRollIn) or 0) - elapsed + 0.5)
	if remaining < 0 then
		remaining = 0
	end
	return remaining
end

local function playUISound(soundName: string): Sound?
	local playerGui = player:FindFirstChild("PlayerGui")
	local sounds = playerGui and playerGui:FindFirstChild("Sounds")
	local sound = sounds and sounds:FindFirstChild(soundName)
	if sound and sound:IsA("Sound") then
		sound:Play()
		return sound
	end
	return nil
end

local function waitForSoundFinished(sound: Sound?, fallbackDuration: number)
	local fallback = math.max(0.1, tonumber(fallbackDuration) or 0.1)
	if not sound then
		task.wait(fallback)
		return
	end

	local ended = false
	local endedConn = sound.Ended:Connect(function()
		ended = true
	end)

	local maxWait = math.max(fallback, (tonumber(sound.TimeLength) or 0) + 0.15)
	local startedAt = os.clock()
	while not ended and os.clock() - startedAt < maxWait do
		task.wait(0.03)
	end

	endedConn:Disconnect()
end

local function getRewardImageId(reward): string
	if type(reward) == "table" and type(reward.imageId) == "string" and reward.imageId ~= "" then
		return reward.imageId
	end

	if type(reward) == "table" and type(reward.name) == "string" then
		local cfg = EnchantConfig.Crystals[reward.name]
		if cfg and type(cfg.imageId) == "string" then
			return cfg.imageId
		end
	end

	return ""
end

local function getRewardColor(reward): Color3
	if type(reward) == "table" and typeof(reward.color) == "Color3" then
		return reward.color
	end

	if type(reward) == "table" and type(reward.name) == "string" then
		local cfg = EnchantConfig.Crystals[reward.name]
		if cfg and typeof(cfg.color) == "Color3" then
			return cfg.color
		end
	end

	return Color3.fromRGB(255, 255, 255)
end

local function resolveUIRefs(): boolean
	local playerGui = player:FindFirstChild("PlayerGui") or player:WaitForChild("PlayerGui")
	local mainUI = playerGui:FindFirstChild("MainUI")
	if not mainUI then
		return false
	end

	local frames = mainUI:FindFirstChild("Frames")
	local enchantingFrame = frames and frames:FindFirstChild("Enchanting")
	local innerEnchantButton = enchantingFrame and enchantingFrame:FindFirstChild("EnchantButton")
	local innerEnchantText = innerEnchantButton and innerEnchantButton:FindFirstChild("TextLabel")
	local notReadyGradient = innerEnchantButton and (innerEnchantButton:FindFirstChild("NotReady") or innerEnchantButton:FindFirstChild("NotReadyGradient"))
	local readyGradient = innerEnchantButton and (innerEnchantButton:FindFirstChild("Ready") or innerEnchantButton:FindFirstChild("ReadyGradient"))

	local progressFrame = enchantingFrame and enchantingFrame:FindFirstChild("ProgressFrame")
	local progressInner = progressFrame and progressFrame:FindFirstChild("Frame")
	local rollsHeader = progressInner and progressInner:FindFirstChild("Header")

	local myMultFrame = enchantingFrame and enchantingFrame:FindFirstChild("MyMultFrame")
	local myMultInner = myMultFrame and myMultFrame:FindFirstChild("Frame")
	local myMultLabel = myMultInner and myMultInner:FindFirstChild("Mult")

	local buy1 = enchantingFrame and enchantingFrame:FindFirstChild("Buy1")
	local buy3 = enchantingFrame and enchantingFrame:FindFirstChild("Buy3")
	local buy10 = enchantingFrame and enchantingFrame:FindFirstChild("Buy10")
	local goalMultLabel = enchantingFrame and enchantingFrame:FindFirstChild("GoalMultLabel")
	local enchantProgressGroup = enchantingFrame and enchantingFrame:FindFirstChild("EnchantProgressBar")
	local enchantProgressBar = enchantProgressGroup and enchantProgressGroup:FindFirstChild("Bar")
	local enchantProgressText = enchantProgressGroup and enchantProgressGroup:FindFirstChild("TextLabel")

	local mainEnchantButton = mainUI:FindFirstChild("EnchantButton")
	local mainPopup = mainEnchantButton and mainEnchantButton:FindFirstChild("Popup")

	local openingFrame = mainUI:FindFirstChild("OpeningFrame")
	local openingTemplate = openingFrame and openingFrame:FindFirstChild("Template")
	if not (enchantingFrame and innerEnchantButton and innerEnchantText and rollsHeader and buy1 and buy3 and buy10 and mainEnchantButton) then
		return false
	end

	refs.enchantingFrame = enchantingFrame
	refs.innerEnchantButton = innerEnchantButton
	refs.innerEnchantText = innerEnchantText
	refs.notReadyGradient = notReadyGradient
	refs.readyGradient = readyGradient
	refs.rollsHeader = rollsHeader
	refs.myMultLabel = myMultLabel
	refs.buy1 = buy1
	refs.buy3 = buy3
	refs.buy10 = buy10
	refs.goalMultLabel = goalMultLabel
	refs.enchantProgressGroup = enchantProgressGroup
	refs.enchantProgressBar = enchantProgressBar
	refs.enchantProgressText = enchantProgressText
	refs.mainEnchantButton = mainEnchantButton
	refs.mainPopup = mainPopup
	refs.openingFrame = openingFrame
	refs.openingTemplate = openingTemplate
	if openingTemplate and openingTemplate:IsA("GuiObject") then
		openingTemplate.Visible = false
	end
	if enchantProgressBar and enchantProgressBar:IsA("Frame") then
		enchantProgressBar.AnchorPoint = Vector2.new(0, 0.5)
		enchantProgressBar.Position = UDim2.new(0, 0, 0.5, 0)
	end

	if mainEnchantButton then
		if not mainButtonBaseSize then
			mainButtonBaseSize = mainEnchantButton.Size
		end
		if mainButtonBaseRotation == nil then
			mainButtonBaseRotation = mainEnchantButton.Rotation
		end
	end
	if goalMultLabel and goalBaseRotation == nil then
		goalBaseRotation = goalMultLabel.Rotation
	end

	return true
end

local function resolveWorldRefs(): boolean
	local tableFolder = workspace:FindFirstChild("EnchantmentTableFolder")
	local tableModel = tableFolder and tableFolder:FindFirstChild("EnchantmentTable")
	local mapParts = workspace:FindFirstChild("MapScriptedParts")
	local zonePart = mapParts and mapParts:FindFirstChild("EnchantmentZone")

	if not (tableModel and tableModel:IsA("Model") and zonePart and zonePart:IsA("BasePart")) then
		return false
	end

	local bookModel = tableModel:FindFirstChild("Book")
	local model = tableModel:FindFirstChild("Model")
	local timerPart = model and model:FindFirstChild("Timer")
	local billboard = timerPart and timerPart:FindFirstChild("BillboardGui")
	local timeLabel = billboard and billboard:FindFirstChild("Time")

	refs.tableModel = tableModel
	refs.zonePart = zonePart
	refs.bookModel = if bookModel and bookModel:IsA("Model") then bookModel else nil
	refs.worldTimerLabel = if timeLabel and timeLabel:IsA("TextLabel") then timeLabel else nil

	if not tableOriginalPivot then
		tableOriginalPivot = tableModel:GetPivot()
	end
	if not zoneOriginalCFrame then
		zoneOriginalCFrame = zonePart.CFrame
	end
	if refs.bookModel and not bookBasePivot then
		bookBasePivot = refs.bookModel:GetPivot()
		bookBaseRelative = CFrame.new(bookBasePivot.Position):ToObjectSpace(bookBasePivot)
	end
	if refs.worldTimerLabel and not timerLabelDefaultColor then
		timerLabelDefaultColor = refs.worldTimerLabel.TextColor3
	end

	return true
end

local function setWorldHidden(hidden: boolean)
	if not resolveWorldRefs() then
		return
	end

	if hidden and not worldHidden then
		if tableOriginalPivot then
			refs.tableModel:PivotTo(tableOriginalPivot * CFrame.new(HIDDEN_OFFSET))
		end
		if zoneOriginalCFrame then
			refs.zonePart.CFrame = zoneOriginalCFrame * CFrame.new(HIDDEN_OFFSET)
		end
		worldHidden = true
	elseif not hidden and worldHidden then
		if tableOriginalPivot then
			refs.tableModel:PivotTo(tableOriginalPivot)
		end
		if zoneOriginalCFrame then
			refs.zonePart.CFrame = zoneOriginalCFrame
		end
		if refs.bookModel then
			bookBasePivot = refs.bookModel:GetPivot()
			bookBaseRelative = CFrame.new(bookBasePivot.Position):ToObjectSpace(bookBasePivot)
		end
		worldHidden = false
	end
end

local function setMainAttentionVisible(visible: boolean)
	if not resolveUIRefs() then
		return
	end

	if mainAttentionVisible == visible then
		if refs.mainPopup and refs.mainPopup:IsA("GuiObject") then
			refs.mainPopup.Visible = visible
		end
		return
	end

	mainAttentionVisible = visible
	if refs.mainPopup and refs.mainPopup:IsA("GuiObject") then
		refs.mainPopup.Visible = visible
	end

	if not visible then
		if refs.mainEnchantButton and mainButtonBaseSize and mainButtonBaseRotation ~= nil then
			refs.mainEnchantButton.Size = mainButtonBaseSize
			refs.mainEnchantButton.Rotation = mainButtonBaseRotation
		end
		return
	end

	if refs.mainEnchantButton and mainButtonBaseSize then
		refs.mainEnchantButton.Size = scaleUDim2(mainButtonBaseSize, 1.15)
		TweenService:Create(
			refs.mainEnchantButton,
			TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
			{ Size = mainButtonBaseSize }
		):Play()
	end
end

local function canOpenEnchantingFrame(): boolean
	if revealInProgress or os.clock() < suppressOpenUntil then
		return false
	end
	if not resolveUIRefs() then
		return false
	end
	if refs.openingFrame and refs.openingFrame.Visible then
		return false
	end
	return true
end

local function openEnchantingFrame()
	if not canOpenEnchantingFrame() then
		return
	end
	UIHandler:OpenFrame(refs.enchantingFrame)
end

local function closeEnchantingFrame()
	if not resolveUIRefs() then
		return
	end
	UIHandler:CloseFrame(refs.enchantingFrame)
end

local function cleanupOpeningCards()
	if not resolveUIRefs() or not refs.openingFrame then
		return
	end

	for _, child in ipairs(refs.openingFrame:GetChildren()) do
		if child:IsA("GuiObject") and child.Name == "RevealCard" then
			child:Destroy()
		end
	end
end


local function getStandPart(): BasePart?
	local character = player.Character
	if not character then
		return nil
	end
	local blade = character:FindFirstChild(BLADE_MODEL_NAME)
	if not blade or not blade:IsA("Model") then
		return nil
	end
	local standPart = blade:FindFirstChild("StandPart")
	if standPart and standPart:IsA("BasePart") then
		return standPart
	end
	return nil
end

local function getCharacterRoot(): BasePart?
	local character = player.Character
	if not character then
		return nil
	end
	local root = character:FindFirstChild("HumanoidRootPart")
	if root and root:IsA("BasePart") then
		return root
	end
	root = character:FindFirstChild("UpperTorso")
	if root and root:IsA("BasePart") then
		return root
	end
	root = character:FindFirstChild("Torso")
	if root and root:IsA("BasePart") then
		return root
	end
	return nil
end

local function clearGuideBeam()
	if guideBeam and guideBeam.Destroy then
		pcall(function()
			guideBeam:Destroy()
		end)
	end
	guideBeam = nil
end

local function getTableGuidePart(): BasePart?
	if not resolveWorldRefs() then
		return nil
	end
	if not refs.tableModel then
		return nil
	end
	local modelPart = refs.tableModel:FindFirstChild("Model")
	if modelPart and modelPart:IsA("BasePart") then
		return modelPart
	end
	if modelPart and modelPart:IsA("Model") then
		local stand = modelPart:FindFirstChild("StandPart")
		if stand and stand:IsA("BasePart") then
			return stand
		end
	end
	return refs.tableModel:FindFirstChildWhichIsA("BasePart", true)
end

local function refreshGuideBeam()
	if not guideShown then
		clearGuideBeam()
		return
	end
	local fromPart = getCharacterRoot()
	local target = guideTargetPart
	if not target or not target.Parent then
		target = getTableGuidePart()
		guideTargetPart = target
	end
	if not (fromPart and target) then
		clearGuideBeam()
		return
	end
	clearGuideBeam()
	guideBeam = MakeBeams.Create(fromPart, target)
end

local function setGuideShown(active: boolean)
	guideShown = active
	if not active then
		clearGuideBeam()
		return
	end
	if not guideTargetPart or not guideTargetPart.Parent then
		guideTargetPart = getTableGuidePart()
	end
	refreshGuideBeam()
end

local function markPromptSeen()
	if guideMarked or state.promptSeen then
		return
	end
	guideMarked = true
	local ok, marked, pushedState = pcall(function()
		return markPromptShownRemote:InvokeServer()
	end)
	if ok and marked == true then
		if type(pushedState) == "table" then
			state.promptSeen = pushedState.promptSeen == true
		else
			state.promptSeen = true
		end
	else
		guideMarked = false
	end
end

local function spawnFallbackOrb(origin: Vector3, destinationPart: BasePart, color: Color3)
	local orb = Instance.new("Part")
	orb.Name = "EnchantOrbFallback"
	orb.Shape = Enum.PartType.Ball
	orb.Material = Enum.Material.Neon
	orb.Color = color
	orb.Size = Vector3.new(1, 1, 1)
	orb.Transparency = 0.15
	orb.Anchored = true
	orb.CanCollide = false
	orb.CanTouch = false
	orb.CanQuery = false
	orb.Position = origin
	orb.Parent = workspace

	local tween = TweenService:Create(
		orb,
		TweenInfo.new(1.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{
			Position = destinationPart.Position,
			Size = Vector3.new(0.2, 0.2, 0.2),
			Transparency = 1,
		}
	)
	tween:Play()
	Debris:AddItem(orb, 1.6)
end

local function spawnRewardOrbs(reward)
	local root = getCharacterRoot()
	if not root then
		return
	end
	local destination = getStandPart() or root
	local color = getRewardColor(reward)

	local orbCount = 3
	for i = 1, orbCount do
		local angle = (i / orbCount) * math.pi * 2
		local radius = 4
		local origin = root.Position + Vector3.new(math.cos(angle) * radius, 2.2 + ((i % 2) * 0.6), math.sin(angle) * radius)
		local ok = pcall(function()
			OrbService.SpawnOrb({
				Origin = origin,
				Destination = destination,
				Color = color,
				Size = 1,
				Duration = 1.8,
				ArcHeight = 70,
				SideOffset = 95,
				TrailLifetime = 0.5,
				TrailWidthStart = 1.5,
				Parent = workspace,
			})
		end)
		if not ok then
			spawnFallbackOrb(origin, destination, color)
		end
	end
end

local function playConfettiOnPlayer()
	local confettiSound = playUISound("Confetti")
	if confettiSound then
		-- already played
	end

	local root = getCharacterRoot()
	if not root then
		return
	end

	local confettiPartTemplate = ReplicatedStorage:WaitForChild("Stuff"):FindFirstChild("ConfettiPart")
	if not confettiPartTemplate or not confettiPartTemplate:IsA("BasePart") then
		return
	end

	local targetFolder = workspace:FindFirstChild("Stuff")
	if not targetFolder then
		targetFolder = Instance.new("Folder")
		targetFolder.Name = "Stuff"
		targetFolder.Parent = workspace
	end

	local confettiPart = confettiPartTemplate:Clone()
	confettiPart.CFrame = root.CFrame
	confettiPart.Parent = targetFolder

	for _, child in ipairs(confettiPart:GetChildren()) do
		if child:IsA("ParticleEmitter") then
			child:Emit(30)
		end
	end

	Debris:AddItem(confettiPart, 3)
end

local function playLocalEnchantVfx()
	local root = getCharacterRoot()
	if not root then
		return
	end

	local vfxFolder = ReplicatedStorage:WaitForChild("Stuff"):WaitForChild("Vfx")
	local template = vfxFolder:FindFirstChild("Enchant")
	if not template or not template:IsA("Attachment") then
		return
	end

	local effect = template:Clone()
	effect.Parent = root

	for _, child in ipairs(effect:GetChildren()) do
		if child:IsA("ParticleEmitter") then
			child:Emit(child.Name == "Particles" and 10 or 2)
		end
	end

	Debris:AddItem(effect, 3)
end

local function createRevealCard(reward, layoutOrder: number)
	if not resolveUIRefs() then
		return nil
	end
	if not refs.openingFrame or not refs.openingTemplate then
		return nil
	end
	if not refs.openingTemplate:IsA("ImageLabel") then
		return nil
	end

	local card = refs.openingTemplate:Clone()
	card.Name = "RevealCard"
	card.Visible = true
	card.LayoutOrder = layoutOrder
	card.Image = ENCHANT_CRATE_IMAGE
	card.ImageTransparency = 0
	card.Rotation = 0
	card.Parent = refs.openingFrame

	local scale = card:FindFirstChildOfClass("UIScale")
	if not scale then
		scale = Instance.new("UIScale")
		scale.Parent = card
	end
	scale.Scale = 0.8

	local ray = card:FindFirstChild("Ray")
	if ray and ray:IsA("ImageLabel") then
		ray.Visible = false
		ray.ImageTransparency = 1
	end

	local bladeImage = ray and ray:FindFirstChild("BladeImage")
	if bladeImage and bladeImage:IsA("ImageLabel") then
		bladeImage.Image = getRewardImageId(reward)
		bladeImage.ImageTransparency = 1
	end

	return {
		card = card,
		scale = scale,
		ray = ray,
		bladeImage = bladeImage,
	}
end

local function playRevealBatch(rewards)
	local entries = {}
	for i, reward in ipairs(rewards) do
		local entry = createRevealCard(reward, i)
		if entry then
			table.insert(entries, entry)
		end
	end
	if #entries == 0 then
		return
	end

	task.wait(0.08 * OPENING_TIME_SCALE)

	for _, entry in ipairs(entries) do
		entry.card.Rotation = -8
		TweenService:Create(entry.scale, TweenInfo.new(0.24 * OPENING_TIME_SCALE, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	end

	local wiggleTweens = {}
	for _, entry in ipairs(entries) do
		local wiggleTween = TweenService:Create(
			entry.card,
			TweenInfo.new(0.08 * OPENING_TIME_SCALE, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
			{ Rotation = 8 }
		)
		wiggleTween:Play()
		table.insert(wiggleTweens, wiggleTween)
	end

	local rattleSound = playUISound("Rattle")
	waitForSoundFinished(rattleSound, 0.5 * OPENING_TIME_SCALE)
	for _, wiggleTween in ipairs(wiggleTweens) do
		wiggleTween:Cancel()
	end

	for _, entry in ipairs(entries) do
		TweenService:Create(
			entry.card,
			TweenInfo.new(0.12 * OPENING_TIME_SCALE, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
			{ Rotation = 0 }
		):Play()
	end

	task.wait(0.08 * OPENING_TIME_SCALE)

	local revealSound = playUISound("Reveal")
	for _, reward in ipairs(rewards) do
		if type(reward) == "table" and (reward.name == "Red" or reward.name == "Gold") then
			playUISound("MythicSound")
			break
		end
	end

	for _, entry in ipairs(entries) do
		entry.card.ImageTransparency = 1
		if entry.ray and entry.ray:IsA("ImageLabel") then
			entry.ray.Visible = true
			TweenService:Create(entry.ray, TweenInfo.new(0.2 * OPENING_TIME_SCALE, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { ImageTransparency = 0 }):Play()
		end
		if entry.bladeImage and entry.bladeImage:IsA("ImageLabel") then
			TweenService:Create(entry.bladeImage, TweenInfo.new(0.22 * OPENING_TIME_SCALE, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { ImageTransparency = 0 }):Play()
		end
		TweenService:Create(entry.scale, TweenInfo.new(0.28 * OPENING_TIME_SCALE, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1.15 }):Play()
	end

	waitForSoundFinished(revealSound, 0.35 * OPENING_TIME_SCALE)
	for _, reward in ipairs(rewards) do
		spawnRewardOrbs(reward)
	end

	task.wait(0.25 * OPENING_TIME_SCALE)

	for _, entry in ipairs(entries) do
		if entry.bladeImage and entry.bladeImage:IsA("ImageLabel") then
			TweenService:Create(entry.bladeImage, TweenInfo.new(0.2 * OPENING_TIME_SCALE, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { ImageTransparency = 1 }):Play()
		end
		if entry.ray and entry.ray:IsA("ImageLabel") then
			TweenService:Create(entry.ray, TweenInfo.new(0.2 * OPENING_TIME_SCALE, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { ImageTransparency = 1 }):Play()
		end
	end

	task.wait(0.12 * OPENING_TIME_SCALE)
	cleanupOpeningCards()
end

local function playEnchantRevealSequence(rewards)
	if not resolveUIRefs() or not refs.openingFrame then
		playLocalEnchantVfx()
		playConfettiOnPlayer()
		return
	end

	refs.openingFrame.Visible = true
	if refs.openingTemplate and refs.openingTemplate:IsA("GuiObject") then
		refs.openingTemplate.Visible = false
	end
	cleanupOpeningCards()

	playRevealBatch(rewards)

	cleanupOpeningCards()
	refs.openingFrame.Visible = false

	playLocalEnchantVfx()
	playConfettiOnPlayer()
end

local function updateUIFromState()
	if not resolveUIRefs() then
		return
	end
	resolveWorldRefs()

	local rolls = math.max(0, math.floor(tonumber(state.rolls) or 0))
	local canRoll = rolls > 0
	local nextRollIn = getEstimatedNextRollIn()
	local enchantTimes = math.max(0, math.floor(tonumber(state.enchantTimes) or 0))
	local enchantGoal = math.max(1, math.floor(tonumber(state.enchantGoal) or 8))
	local progressAlpha = math.clamp(enchantTimes / enchantGoal, 0, 1)

	refs.rollsHeader.Text = "x" .. tostring(rolls)
	if refs.myMultLabel and refs.myMultLabel:IsA("TextLabel") then
		refs.myMultLabel.Text = string.format("x%.2f", tonumber(state.enchantMult) or 1)
	end
	if refs.enchantProgressText and refs.enchantProgressText:IsA("TextLabel") then
		refs.enchantProgressText.Text = string.format("%d/%d", enchantTimes, enchantGoal)
	end
	if refs.enchantProgressBar and refs.enchantProgressBar:IsA("Frame") then
		refs.enchantProgressBar.Size = UDim2.new(progressAlpha, 0, 1, 0)
	end

	if canRoll then
		refs.innerEnchantText.Text = "ENCHANT"
	else
		refs.innerEnchantText.Text = formatMMSS(nextRollIn)
	end

	if refs.readyGradient and refs.readyGradient:IsA("UIGradient") then
		refs.readyGradient.Enabled = canRoll
	end
	if refs.notReadyGradient and refs.notReadyGradient:IsA("UIGradient") then
		refs.notReadyGradient.Enabled = not canRoll
	end

	if refs.worldTimerLabel and refs.worldTimerLabel:IsA("TextLabel") then
		if canRoll then
			refs.worldTimerLabel.Text = "Ready!"
			refs.worldTimerLabel.TextColor3 = READY_COLOR
		else
			refs.worldTimerLabel.Text = "Next Enchant in " .. formatMMSS(nextRollIn)
			if timerLabelDefaultColor then
				refs.worldTimerLabel.TextColor3 = timerLabelDefaultColor
			end
		end
	end

	setMainAttentionVisible(canRoll and not attentionAcknowledged)
end

local function applyState(newState)
	if type(newState) ~= "table" then
		return
	end

	local previousHadRoll = (tonumber(state.rolls) or 0) > 0

	state.rolls = math.max(0, math.floor(tonumber(newState.rolls) or 0))
	state.nextRollIn = math.max(0, math.floor(tonumber(newState.nextRollIn) or (5 * 60)))
	state.canRoll = state.rolls > 0
	state.enchantMult = tonumber(newState.enchantMult) or state.enchantMult or 1
	state.enchantTimes = math.max(0, math.floor(tonumber(newState.enchantTimes) or state.enchantTimes or 0))
	state.enchantGoal = math.max(1, math.floor(tonumber(newState.enchantGoal) or state.enchantGoal or 8))
	state.enchantProgressBonus = math.max(0, tonumber(newState.enchantProgressBonus) or state.enchantProgressBonus or 0)
	if newState.promptSeen ~= nil then
		state.promptSeen = newState.promptSeen == true
	end
	state.serverTime = math.floor(tonumber(newState.serverTime) or os.time())
	stateAppliedAt = os.clock()

	if state.promptSeen then
		guideMarked = true
	end

	if (not previousHadRoll) and state.rolls > 0 then
		attentionAcknowledged = false
		if not state.promptSeen and not guideShown then
			setGuideShown(true)
			markPromptSeen()
		end
	end
	if state.rolls <= 0 then
		attentionAcknowledged = false
		setGuideShown(false)
	end

	updateUIFromState()
end

local function applyStateFromAttributes()
	local rolls = player:GetAttribute("EnchantRolls")
	local nextRollIn = player:GetAttribute("EnchantNextRollIn")
	local enchantMult = player:GetAttribute("EnchantMult")
	local enchantTimes = player:GetAttribute("EnchantTimes")
	local enchantGoal = player:GetAttribute("EnchantGoal")
	local enchantProgressBonus = player:GetAttribute("EnchantProgressBonus")
	local promptSeen = player:GetAttribute("EnchantPromptSeen")

	if rolls == nil and nextRollIn == nil and enchantMult == nil and enchantTimes == nil and enchantGoal == nil and enchantProgressBonus == nil and promptSeen == nil then
		return
	end

	applyState({
		rolls = tonumber(rolls) or 0,
		nextRollIn = tonumber(nextRollIn) or (5 * 60),
		enchantMult = tonumber(enchantMult) or 1,
		enchantTimes = tonumber(enchantTimes) or 0,
		enchantGoal = tonumber(enchantGoal) or 8,
		enchantProgressBonus = tonumber(enchantProgressBonus) or 0,
		promptSeen = promptSeen == true,
		serverTime = os.time(),
	})
end

local function requestState()
	local ok, response = pcall(function()
		return getStateRemote:InvokeServer()
	end)
	if ok and type(response) == "table" then
		applyState(response)
	end
end

local function promptProduct(productId: number)
	MarketplaceService:PromptProductPurchase(player, productId)
end

local function bindButtons()
	if not resolveUIRefs() then
		return
	end

	if bound.mainButton ~= refs.mainEnchantButton then
		bound.mainButton = refs.mainEnchantButton
		refs.mainEnchantButton.Activated:Connect(function()
			if revealInProgress or os.clock() < suppressOpenUntil then
				return
			end
			attentionAcknowledged = true
			setMainAttentionVisible(false)
			setGuideShown(false)
			openEnchantingFrame()
		end)
	end

	if bound.enchantButton ~= refs.innerEnchantButton then
		bound.enchantButton = refs.innerEnchantButton
		refs.innerEnchantButton.Activated:Connect(function()
			if revealInProgress or os.clock() < suppressOpenUntil then
				return
			end

			local currentRolls = math.max(0, math.floor(tonumber(state.rolls) or 0))
			if currentRolls <= 0 then
				promptProduct(BUY_1_PRODUCT_ID)
				return
			end

			revealInProgress = true
			suppressOpenUntil = os.clock() + 8

			local consumeCount = math.clamp(currentRolls, 1, 3)
			local ok, response = pcall(function()
				return useRollRemote:InvokeServer(consumeCount)
			end)

			if not ok or type(response) ~= "table" then
				revealInProgress = false
				suppressOpenUntil = os.clock() + 0.5
				return
			end

			if type(response.state) == "table" then
				applyState(response.state)
			else
				requestState()
			end

			if response.ok ~= true then
				revealInProgress = false
				suppressOpenUntil = os.clock() + 0.5
				return
			end

			playUISound("Enchant")
			attentionAcknowledged = true
			setMainAttentionVisible(false)
			setGuideShown(false)
			closeEnchantingFrame()
			local rewards = {}
			if type(response.rewards) == "table" and #response.rewards > 0 then
				rewards = response.rewards
			elseif type(response.reward) == "table" then
				rewards = { response.reward }
			end

			task.spawn(function()
				if #rewards > 0 then
					playEnchantRevealSequence(rewards)
				else
					playLocalEnchantVfx()
					playConfettiOnPlayer()
				end
				revealInProgress = false
				suppressOpenUntil = os.clock() + 3
			end)
		end)
	end

	if bound.buy1 ~= refs.buy1 then
		bound.buy1 = refs.buy1
		refs.buy1.Activated:Connect(function()
			promptProduct(BUY_1_PRODUCT_ID)
		end)
	end

	if bound.buy3 ~= refs.buy3 then
		bound.buy3 = refs.buy3
		refs.buy3.Activated:Connect(function()
			promptProduct(BUY_3_PRODUCT_ID)
		end)
	end

	if bound.buy10 ~= refs.buy10 then
		bound.buy10 = refs.buy10
		refs.buy10.Activated:Connect(function()
			promptProduct(BUY_10_PRODUCT_ID)
		end)
	end
end

openEnchantingRemote.OnClientEvent:Connect(function()
	setGuideShown(false)
	openEnchantingFrame()
end)

player:GetAttributeChangedSignal("EnchantRolls"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantNextRollIn"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantCanRoll"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantMult"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantTimes"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantGoal"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantProgressBonus"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("EnchantPromptSeen"):Connect(applyStateFromAttributes)
player:GetAttributeChangedSignal("TutorialCompleted"):Connect(function()
	local tutorialCompleted = player:GetAttribute("TutorialCompleted") == true
	setWorldHidden(not tutorialCompleted)
end)

player.CharacterAdded:Connect(function()
	task.wait(0.35)
	bindButtons()
	applyStateFromAttributes()
	updateUIFromState()
	refreshGuideBeam()
	local tutorialCompleted = player:GetAttribute("TutorialCompleted") == true
	setWorldHidden(not tutorialCompleted)
end)

requestState()
applyStateFromAttributes()
bindButtons()
updateUIFromState()

local tutorialCompleted = player:GetAttribute("TutorialCompleted") == true
setWorldHidden(not tutorialCompleted)

RunService.RenderStepped:Connect(function()
	if resolveUIRefs() and refs.goalMultLabel and refs.goalMultLabel:IsA("GuiObject") then
		if goalBaseRotation == nil then
			goalBaseRotation = refs.goalMultLabel.Rotation
		end
		refs.goalMultLabel.Rotation = (goalBaseRotation or 0) + math.sin(os.clock() * 3) * 6
	end

	if resolveUIRefs() and refs.mainEnchantButton and mainButtonBaseSize and mainButtonBaseRotation ~= nil then
		if mainAttentionVisible then
			refs.mainEnchantButton.Rotation = mainButtonBaseRotation + math.sin(os.clock() * 7) * 8
			refs.mainEnchantButton.Size = scaleUDim2(mainButtonBaseSize, 1 + (math.sin(os.clock() * 9) * 0.05))
		else
			refs.mainEnchantButton.Rotation = mainButtonBaseRotation
			refs.mainEnchantButton.Size = mainButtonBaseSize
		end
	end

	if resolveWorldRefs() and not worldHidden and refs.bookModel and refs.bookModel:IsA("Model") and bookBasePivot then
		local t = os.clock()
		local bobY = math.sin(t * 0.8) * 1
		local orbitX = math.cos(t * 0.35) * 0.25
		local orbitZ = math.sin(t * 0.35) * 0.25
		local yaw = math.rad(t * 12)
		local basePos = bookBasePivot.Position
		local finalCFrame = CFrame.new(basePos + Vector3.new(orbitX, bobY, orbitZ)) * CFrame.Angles(0, yaw, 0) * (bookBaseRelative or CFrame.new())
		refs.bookModel:PivotTo(finalCFrame)
	end
end)

task.spawn(function()
	while true do
		bindButtons()
		updateUIFromState()
		local completed = player:GetAttribute("TutorialCompleted") == true
		setWorldHidden(not completed)
		if guideShown and not guideBeam then
			refreshGuideBeam()
		end
		task.wait(0.2)
	end
end)