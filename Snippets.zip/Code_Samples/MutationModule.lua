local module = {}

local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local Toaster = require(ServerScriptService:WaitForChild("Toaster"))

local Atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")
if not Atmosphere then
	Atmosphere = Instance.new("Atmosphere")
	Atmosphere.Parent = Lighting
end
local ReplicatedStuff = ReplicatedStorage:FindFirstChild("Stuff")
local WorldEmitterTemplate = ReplicatedStuff and ReplicatedStuff:FindFirstChild("WorldEmitter") or nil
local StuffFolder = workspace:FindFirstChild("Stuff")
local WorldEmitter = workspace:FindFirstChild("WorldEmitter") or (StuffFolder and StuffFolder:FindFirstChild("WorldEmitter")) or nil
if not WorldEmitter and WorldEmitterTemplate and WorldEmitterTemplate:IsA("BasePart") then
	WorldEmitter = WorldEmitterTemplate:Clone()
	WorldEmitter.Name = "WorldEmitter"
	WorldEmitter.Parent = workspace
end
local SkyFolder = ReplicatedStorage:FindFirstChild("Sky")

local MutationRoot = workspace:WaitForChild("ServerMutations")
local MutationSign = MutationRoot:WaitForChild("MutationSign")
local SurfaceGui = MutationSign:WaitForChild("SurfaceGui")
local SignFrame = SurfaceGui:WaitForChild("Frame")
local TimerLabel = SignFrame:WaitForChild("Timer")
local BarBackground = SignFrame:WaitForChild("BarBackground")
local Bar = BarBackground:WaitForChild("Bar")

local EVENT_NAME = "Blood Moon"
local EVENT_COLOR = Color3.fromRGB(223, 25, 12)
local LIME_GREEN = Color3.fromRGB(0, 255, 0)
local RED = Color3.fromRGB(255, 0, 0)

local EVENT_DURATION = 5 * 60
local DOWNTIME_DURATION = 25 * 60
local WARNING_FIVE_MINUTES = 5 * 60
local WARNING_ONE_MINUTE = 60

local PHASE_COUNTDOWN = "countdown"
local PHASE_ACTIVE = "active"

local schedulerStarted = false
local phase = PHASE_COUNTDOWN
local phaseEndsAt = 0
local warnedFiveMinutes = false
local warnedOneMinute = false

local function findParticleEmitter(root: Instance?): ParticleEmitter?
	if not root then
		return nil
	end
	if root:IsA("ParticleEmitter") then
		return root
	end

	local direct = root:FindFirstChildOfClass("ParticleEmitter")
	if direct then
		return direct
	end

	for _, descendant in ipairs(root:GetDescendants()) do
		if descendant:IsA("ParticleEmitter") then
			return descendant
		end
	end

	return nil
end

local ColorCorrection = Lighting:FindFirstChildOfClass("ColorCorrectionEffect")
if not ColorCorrection then
	ColorCorrection = Instance.new("ColorCorrectionEffect")
	ColorCorrection.Name = "BloodMoonColorCorrection"
	ColorCorrection.Parent = Lighting
end

local defaultAtmosphereGlare = Atmosphere.Glare
local defaultAtmosphereDensity = Atmosphere.Density
local defaultAtmosphereColor = Atmosphere.Color
local defaultAtmosphereDecay = Atmosphere.Decay
local defaultClockTime = Lighting.ClockTime

local defaultColorCorrectionTint = ColorCorrection.TintColor
local defaultColorCorrectionContrast = ColorCorrection.Contrast
local defaultColorCorrectionSaturation = ColorCorrection.Saturation
local defaultColorCorrectionBrightness = ColorCorrection.Brightness

local particleEmitter = findParticleEmitter(WorldEmitter)
local defaultEmitterEnabled = particleEmitter and particleEmitter.Enabled or false
local defaultEmitterColor = particleEmitter and particleEmitter.Color or ColorSequence.new(Color3.new(1, 1, 1))

local function formatMMSS(seconds: number): string
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	local mm = math.floor(seconds / 60)
	local ss = seconds % 60
	return string.format("%02d:%02d", mm, ss)
end

local function setAttributes(active: boolean, currentPhase: string, remaining: number)
	ReplicatedStorage:SetAttribute("BloodMoonActive", active)
	ReplicatedStorage:SetAttribute("BloodMoonPhase", currentPhase)
	ReplicatedStorage:SetAttribute("BloodMoonRemaining", math.max(0, math.floor(tonumber(remaining) or 0)))

	if active then
		ReplicatedStorage:SetAttribute("CurrentEvent", EVENT_NAME)
		ReplicatedStorage:SetAttribute("CurrentEventColor", EVENT_COLOR)
	else
		ReplicatedStorage:SetAttribute("CurrentEvent", nil)
		ReplicatedStorage:SetAttribute("CurrentEventColor", nil)
	end
end

local function updateCountdownSign(remaining: number)
	local elapsed = math.max(0, DOWNTIME_DURATION - remaining)
	local alpha = DOWNTIME_DURATION > 0 and (elapsed / DOWNTIME_DURATION) or 0
	alpha = math.clamp(alpha, 0, 1)

	Bar.BackgroundColor3 = LIME_GREEN
	Bar.AnchorPoint = Vector2.new(0, 0.5)
	Bar.Position = UDim2.new(0, 0, 0.5, 0)
	Bar.Size = UDim2.new(alpha, 0, 1, 0)
	TimerLabel.Text = formatMMSS(remaining)
end

local function updateActiveSign(remaining: number)
	local alpha = EVENT_DURATION > 0 and (remaining / EVENT_DURATION) or 0
	alpha = math.clamp(alpha, 0, 1)

	Bar.BackgroundColor3 = RED
	Bar.AnchorPoint = Vector2.new(0, 0.5)
	Bar.Position = UDim2.new(0, 0, 0.5, 0)
	Bar.Size = UDim2.new(alpha, 0, 1, 0)
	TimerLabel.Text = "NOW!"
end

local function setSkyByName(name: string)
	local skyTemplate = SkyFolder and SkyFolder:FindFirstChild(name) or nil
	if not skyTemplate or not skyTemplate:IsA("Sky") then
		return
	end

	local currentSky = Lighting:FindFirstChild("Sky")
	if currentSky then
		currentSky:Destroy()
	end

	local newSky = skyTemplate:Clone()
	newSky.Name = "Sky"
	newSky.Parent = Lighting
end

local function applyBloodMoonVisuals()
	setSkyByName("BloodMoon")

	Atmosphere.Glare = 0.5
	Atmosphere.Density = 0.33
	Atmosphere.Color = Color3.fromRGB(170, 70, 70)
	Atmosphere.Decay = Color3.fromRGB(130, 45, 45)
	Lighting.ClockTime = 18

	ColorCorrection.TintColor = Color3.fromRGB(255, 150, 150)
	ColorCorrection.Contrast = 0.12
	ColorCorrection.Saturation = 0.05
	ColorCorrection.Brightness = 0.03

	if particleEmitter then
		particleEmitter.Color = ColorSequence.new(Color3.fromRGB(255, 70, 70))
		particleEmitter.Enabled = true
	end
end

local function restoreDefaultVisuals()
	setSkyByName("Default")

	Atmosphere.Glare = defaultAtmosphereGlare
	Atmosphere.Density = defaultAtmosphereDensity
	Atmosphere.Color = defaultAtmosphereColor
	Atmosphere.Decay = defaultAtmosphereDecay
	Lighting.ClockTime = defaultClockTime

	ColorCorrection.TintColor = defaultColorCorrectionTint
	ColorCorrection.Contrast = defaultColorCorrectionContrast
	ColorCorrection.Saturation = defaultColorCorrectionSaturation
	ColorCorrection.Brightness = defaultColorCorrectionBrightness

	if particleEmitter then
		particleEmitter.Color = defaultEmitterColor
		particleEmitter.Enabled = defaultEmitterEnabled
	end
end

local function beginCountdown()
	phase = PHASE_COUNTDOWN
	phaseEndsAt = os.time() + DOWNTIME_DURATION
	warnedFiveMinutes = false
	warnedOneMinute = false

	setAttributes(false, phase, DOWNTIME_DURATION)
	updateCountdownSign(DOWNTIME_DURATION)
end

local function startEvent()
	phase = PHASE_ACTIVE
	phaseEndsAt = os.time() + EVENT_DURATION

	applyBloodMoonVisuals()
	Toaster.AddToastAll("Blood Moon has started!", EVENT_COLOR)

	setAttributes(true, phase, EVENT_DURATION)
	updateActiveSign(EVENT_DURATION)
end

local function endEvent()
	restoreDefaultVisuals()
	Toaster.AddToastAll("Blood Moon has ended!", Color3.fromRGB(255, 255, 255))
	beginCountdown()
end

function module.IsActive(): boolean
	return phase == PHASE_ACTIVE
end

function module.GetSpeedMultiplier(): number
	if module.IsActive() then
		return 2
	end
	return 1
end

function module.ForceStart(playerName: string?): boolean
	if module.IsActive() then
		return false
	end

	if type(playerName) == "string" and playerName ~= "" then
		Toaster.AddToastAll(playerName .. " forced a blood moon!", EVENT_COLOR)
	end

	startEvent()
	return true
end

function module.StartEvent(): boolean
	return module.ForceStart(nil)
end

function module.StartScheduler()
	if schedulerStarted then
		return
	end
	schedulerStarted = true

	if phaseEndsAt <= 0 then
		beginCountdown()
	else
		local remaining = math.max(0, phaseEndsAt - os.time())
		if phase == PHASE_ACTIVE then
			setAttributes(true, phase, remaining)
			updateActiveSign(remaining)
		else
			setAttributes(false, phase, remaining)
			updateCountdownSign(remaining)
		end
	end

	task.spawn(function()
		while true do
			task.wait(1)
			local now = os.time()
			local remaining = math.max(0, phaseEndsAt - now)

			if phase == PHASE_COUNTDOWN then
				if not warnedFiveMinutes and remaining <= WARNING_FIVE_MINUTES then
					warnedFiveMinutes = true
					Toaster.AddToastAll("Blood Moon is starting in 5 minutes!", EVENT_COLOR)
				end
				if not warnedOneMinute and remaining <= WARNING_ONE_MINUTE then
					warnedOneMinute = true
					Toaster.AddToastAll("Blood Moon is starting in 1 minute!", EVENT_COLOR)
				end

				setAttributes(false, phase, remaining)
				updateCountdownSign(remaining)

				if remaining <= 0 then
					startEvent()
				end
			else
				setAttributes(true, phase, remaining)
				updateActiveSign(remaining)

				if remaining <= 0 then
					endEvent()
				end
			end
		end
	end)
end

return module