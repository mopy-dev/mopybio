local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local ProductManager = require(ServerScriptService:WaitForChild("MonetizationService"):WaitForChild("ProductManager"))
local TrollService = require(ServerScriptService:WaitForChild("TrollService"))

local PRODUCT_BY_ACTION = {
	Kick = 3558859008,
	KickAll = 3558859761,
	Kill = 3558858884,
	KillAll = 3558859945,
	Nuke = 3558859260,
	SetFire = 3558859160,
	Slow = 3558859563,
	Fling = 3558858671,
}

local TARGET_REQUIRED = {
	Kick = true,
	Kill = true,
	Nuke = true,
	SetFire = true,
	Slow = true,
	Fling = true,
}

local function ensureChild(parent, name, className)
	local existing = parent:FindFirstChild(name)
	if existing and existing:IsA(className) then
		return existing
	end
	if existing then
		existing:Destroy()
	end
	local child = Instance.new(className)
	child.Name = name
	child.Parent = parent
	return child
end

local remotesRoot = ReplicatedStorage:FindFirstChild("Remotes") or ReplicatedStorage:FindFirstChild("RemoteEvents")
if not remotesRoot then
	remotesRoot = Instance.new("Folder")
	remotesRoot.Name = "RemoteEvents"
	remotesRoot.Parent = ReplicatedStorage
end

local monetizationFolder = ensureChild(remotesRoot, "Monetization", "Folder")
local productsFolder = ensureChild(monetizationFolder, "Products", "Folder")
local trollFolder = ensureChild(productsFolder, "Troll", "Folder")

local setTargetRemote = ensureChild(trollFolder, "SetTarget", "RemoteEvent")
local remotes = {}
for actionName in pairs(PRODUCT_BY_ACTION) do
	remotes[actionName] = ensureChild(trollFolder, actionName, "RemoteEvent")
end

setTargetRemote.OnServerEvent:Connect(function(player, targetUserId)
	TrollService.SetTarget(player, targetUserId)
end)

local function ensureTarget(player)
	if TrollService.GetTargetPlayer(player) then
		return true
	end
	return TrollService.AutoSelectTarget(player) ~= nil
end

for actionName, remote in pairs(remotes) do
	remote.OnServerEvent:Connect(function(player)
		if TARGET_REQUIRED[actionName] and not ensureTarget(player) then
			return
		end

		local productId = PRODUCT_BY_ACTION[actionName]
		if productId then
			ProductManager.ProductPurchaseRequested(player, productId)
		end
	end)
end