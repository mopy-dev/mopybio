local FunnelService = {}

local AnalyticsService = game:GetService("AnalyticsService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local XPService = require(game.ServerScriptService:WaitForChild("XPService"))

local FUNNEL_IDS = {
	Tutorial = "funnel_1_tutorial",
	LeaveReward = "funnel_2_leave_reward",
	Stages = "funnel_3_stages",
	Shop = "funnel_4_shop",
	Offers = "funnel_5_offers",
	Invite = "funnel_6_invites",
	Milestones = "funnel_7_milestones",
}

local OFFER_STARTER_PACK_PRODUCT_ID = 3557661099

local sessions: {[Player]: {[string]: any}} = {}
local profileByPlayer: {[Player]: any} = {}

local function getOrCreateFolder(parent: Instance, name: string): Folder
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder :: Folder
end

local function getOrCreateRemoteEvent(parent: Instance, name: string): RemoteEvent
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteEvent") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = parent
	end
	return remote :: RemoteEvent
end

local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
local analyticsFolder = getOrCreateFolder(remoteEvents, "Analytics")
local trackEventRemote = getOrCreateRemoteEvent(analyticsFolder, "TrackEvent")

local function ensureSession(player: Player)
	local session = sessions[player]
	if session then
		return session
	end

	session = {
		funnelSteps = {},
		offerPendingProductId = nil,
		offerPendingKey = nil,
		funnelSessionId = string.format("s_%d_%s_%d", player.UserId, string.sub(game.JobId, 1, 8), os.time()),
	}
	sessions[player] = session
	return session
end

local function ensureProfileAnalytics(profile)
	if type(profile) ~= "table" or type(profile.Data) ~= "table" then
		return nil
	end

	local data = profile.Data
	if type(data.Analytics) ~= "table" then
		data.Analytics = {}
	end
	local analytics = data.Analytics

	if type(analytics.Funnels) ~= "table" then
		analytics.Funnels = {}
	end
	if type(analytics.LevelTimes) ~= "table" then
		analytics.LevelTimes = {}
	end
	if type(analytics.TrainingTotals) ~= "table" then
		analytics.TrainingTotals = {
			inTraining = 0,
			outside = 0,
		}
	end
	if type(analytics.UserFunnelSessionId) ~= "string" or analytics.UserFunnelSessionId == "" then
		analytics.UserFunnelSessionId = nil
	end

	return analytics
end

local function getUserFunnelSessionId(player: Player, analytics): string
	if type(analytics.UserFunnelSessionId) ~= "string" or analytics.UserFunnelSessionId == "" then
		analytics.UserFunnelSessionId = string.format("u_%d", player.UserId)
	end
	return analytics.UserFunnelSessionId
end

local function getSessionFunnelSessionId(player: Player): string
	local session = ensureSession(player)
	if type(session.funnelSessionId) ~= "string" or session.funnelSessionId == "" then
		session.funnelSessionId = string.format("s_%d_%s_%d", player.UserId, string.sub(game.JobId, 1, 8), os.time())
	end
	return session.funnelSessionId
end

local function tryLogFunnelStep(player: Player, funnelId: string, funnelSessionId: string, stepName: string, stepIndex: number?)
	local step = math.max(1, math.floor(tonumber(stepIndex) or 1))
	local ok = false

	ok = pcall(function()
		AnalyticsService:LogFunnelStepEvent(player, funnelId, funnelSessionId, step, stepName, {})
	end)
	if ok then
		return
	end

	ok = pcall(function()
		AnalyticsService:LogFunnelStepEvent(player, funnelId, funnelSessionId, step, stepName)
	end)
	if ok then
		return
	end

	ok = pcall(function()
		AnalyticsService:LogFunnelStepEvent(player, funnelId, step, stepName)
	end)
	if ok then
		return
	end

	pcall(function()
		AnalyticsService:FireCustomEvent(player, "funnel_step", {
			funnel = funnelId,
			sessionId = funnelSessionId,
			step = stepName,
			index = step,
		})
	end)
end

local function tryLogCustom(player: Player, eventName: string, payload: {[string]: any}?)
	payload = payload or {}
	local ok = pcall(function()
		AnalyticsService:FireCustomEvent(player, eventName, payload)
	end)
	if ok then
		return
	end

	pcall(function()
		AnalyticsService:LogCustomEvent(player, eventName, payload)
	end)
end

local function trackUserStep(player: Player, funnelId: string, stepName: string, stepIndex: number?)
	local profile = profileByPlayer[player]
	if not profile then
		return false
	end

	local analytics = ensureProfileAnalytics(profile)
	if not analytics then
		return false
	end

	local funnels = analytics.Funnels
	if type(funnels[funnelId]) ~= "table" then
		funnels[funnelId] = {}
	end
	if funnels[funnelId][stepName] == true then
		return false
	end

	funnels[funnelId][stepName] = true
	tryLogFunnelStep(player, funnelId, getUserFunnelSessionId(player, analytics), stepName, stepIndex)
	return true
end

local function trackSessionStep(player: Player, funnelId: string, stepName: string, stepIndex: number?)
	local session = ensureSession(player)
	local sessionFunnels = session.funnelSteps
	if type(sessionFunnels[funnelId]) ~= "table" then
		sessionFunnels[funnelId] = {}
	end
	if sessionFunnels[funnelId][stepName] == true then
		return false
	end

	sessionFunnels[funnelId][stepName] = true
	tryLogFunnelStep(player, funnelId, getSessionFunnelSessionId(player), stepName, stepIndex)
	return true
end
local function getCurrentLevelFromProfile(profile): number
	if type(profile) ~= "table" or type(profile.Data) ~= "table" then
		return 0
	end
	local speed = math.max(0, math.floor(tonumber(profile.Data.Speed) or 0))
	local rebirths = math.max(0, math.floor(tonumber(profile.Data.Rebirths) or 0))
	local info = XPService.GetProgressInfo(speed, rebirths)
	return math.max(0, math.floor(tonumber(info.currentLevel) or 0))
end

function FunnelService.InitializePlayer(player: Player, profile)
	profileByPlayer[player] = profile
	ensureSession(player)
	ensureProfileAnalytics(profile)

	trackUserStep(player, FUNNEL_IDS.Tutorial, "join", 1)
	trackUserStep(player, FUNNEL_IDS.LeaveReward, "join", 1)
	trackUserStep(player, FUNNEL_IDS.Stages, "joined", 1)
	trackUserStep(player, FUNNEL_IDS.Milestones, "joined", 1)

	trackSessionStep(player, FUNNEL_IDS.Shop, "joined", 1)
	trackSessionStep(player, FUNNEL_IDS.Invite, "joined", 1)
	local wins = math.max(0, math.floor(tonumber(profile.Data.Wins) or 0))
	FunnelService.TrackWinsProgress(player, wins, profile)

	local level = getCurrentLevelFromProfile(profile)
	FunnelService.TrackLevelProgress(player, level, profile)

	local rebirths = math.max(0, math.floor(tonumber(profile.Data.Rebirths) or 0))
	FunnelService.TrackRebirthProgress(player, rebirths, profile)

	local equippedTier = math.max(1, math.floor(tonumber(profile.Data.Mults and profile.Data.Mults.Equipped) or 1))
	if equippedTier == 2 then
		FunnelService.TrackTutorialSword2Equipped(player, profile)
	end
end

function FunnelService.OnPlayerRemoving(player: Player)
	sessions[player] = nil
	profileByPlayer[player] = nil
end

function FunnelService.TrackTreadmillEntered(player: Player)
	trackUserStep(player, FUNNEL_IDS.Tutorial, "go_to_treadmill", 2)
end

function FunnelService.TrackLevelProgress(player: Player, level: number, profile)
	if profile then
		profileByPlayer[player] = profile
	end

	level = math.max(0, math.floor(tonumber(level) or 0))
	if level >= 3 then
		trackUserStep(player, FUNNEL_IDS.Tutorial, "train_to_level_3", 3)
	end
	if level >= 10 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "level_10", 2)
	end
	if level >= 20 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "level_20", 3)
	end
	if level >= 30 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "level_30", 4)
	end
end

function FunnelService.TrackWinsProgress(player: Player, wins: number, profile)
	if profile then
		profileByPlayer[player] = profile
	end

	wins = math.max(0, math.floor(tonumber(wins) or 0))
	if wins >= 1 then
		trackUserStep(player, FUNNEL_IDS.Tutorial, "get_1_win", 4)
	end
	if wins >= 2 then
		trackUserStep(player, FUNNEL_IDS.Tutorial, "get_2_wins", 5)
	end
end

function FunnelService.TrackTutorialSword2Equipped(player: Player, profile)
	if profile then
		profileByPlayer[player] = profile
	end
	trackUserStep(player, FUNNEL_IDS.Tutorial, "equip_sword_2", 6)
end

function FunnelService.TrackLeaveRewardSeen(player: Player)
	trackUserStep(player, FUNNEL_IDS.LeaveReward, "seen_leave_reward", 2)
end

function FunnelService.TrackLeaveRewardClaimed(player: Player, profile)
	if profile then
		profileByPlayer[player] = profile
	end
	trackUserStep(player, FUNNEL_IDS.LeaveReward, "claimed_leave_reward", 3)
end

function FunnelService.TrackStageTouched(player: Player, stageIndex: number)
	stageIndex = math.max(1, math.floor(tonumber(stageIndex) or 0))
	if stageIndex > 12 then
		stageIndex = 12
	end
	trackUserStep(player, FUNNEL_IDS.Stages, "stage_" .. tostring(stageIndex), stageIndex + 1)
end

function FunnelService.TrackRebirthProgress(player: Player, rebirths: number, profile)
	if profile then
		profileByPlayer[player] = profile
	end

	rebirths = math.max(0, math.floor(tonumber(rebirths) or 0))
	if rebirths >= 1 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "rebirth_1", 5)
	end
	if rebirths >= 2 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "rebirth_2", 6)
	end
	if rebirths >= 3 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "rebirth_3", 7)
	end
	if rebirths >= 5 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "rebirth_5", 8)
	end
	if rebirths >= 8 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "rebirth_8", 9)
	end
	if rebirths >= 10 then
		trackUserStep(player, FUNNEL_IDS.Milestones, "rebirth_10", 10)
	end
end

function FunnelService.TrackPurchaseCompleted(player: Player, productId: number)
	local session = ensureSession(player)
	local shopSteps = session.funnelSteps[FUNNEL_IDS.Shop]
	if type(shopSteps) == "table" and shopSteps.clicked_buy == true then
		trackSessionStep(player, FUNNEL_IDS.Shop, "bought_something", 5)
	end
	productId = math.floor(tonumber(productId) or 0)
	if productId <= 0 then
		return
	end

	local pendingProductId = tonumber(session.offerPendingProductId)
	if pendingProductId and pendingProductId > 0 and pendingProductId == productId then
		trackSessionStep(player, FUNNEL_IDS.Offers, "offer_bought", 3)
		session.offerPendingProductId = nil
		session.offerPendingKey = nil
		return
	end

	if session.offerPendingKey == "StarterPack" and productId == OFFER_STARTER_PACK_PRODUCT_ID then
		trackSessionStep(player, FUNNEL_IDS.Offers, "offer_bought", 3)
		session.offerPendingProductId = nil
		session.offerPendingKey = nil
	end
end

local function onClientEvent(player: Player, eventName: any, payload: any)
	if type(eventName) ~= "string" then
		return
	end
	if type(payload) ~= "table" then
		payload = {}
	end

	if eventName == "shop_clicked" then
		trackSessionStep(player, FUNNEL_IDS.Shop, "clicked_shop_button", 2)
		return
	end

	if eventName == "shop_scrolled" then
		trackSessionStep(player, FUNNEL_IDS.Shop, "shop_scrolled", 3)
		return
	end

	if eventName == "shop_buy_clicked" then
		trackSessionStep(player, FUNNEL_IDS.Shop, "clicked_buy", 4)
		return
	end

	if eventName == "offer_seen" then
		trackSessionStep(player, FUNNEL_IDS.Offers, "offer_seen", 1)
		tryLogCustom(player, "offer_seen_detail", {
			offerKey = tostring(payload.offerKey or ""),
			productId = tonumber(payload.productId) or 0,
		})
		return
	end

	if eventName == "offer_clicked" then
		trackSessionStep(player, FUNNEL_IDS.Offers, "offer_clicked", 2)
		local session = ensureSession(player)
		session.offerPendingProductId = tonumber(payload.productId)
		session.offerPendingKey = tostring(payload.offerKey or session.offerPendingKey or "")
		return
	end

	if eventName == "invite_clicked" then
		trackSessionStep(player, FUNNEL_IDS.Invite, "invited_friends", 2)
		return
	end

	if eventName == "leave_reward_seen" then
		FunnelService.TrackLeaveRewardSeen(player)
		return
	end
end

trackEventRemote.OnServerEvent:Connect(onClientEvent)

Players.PlayerRemoving:Connect(function(player)
	FunnelService.OnPlayerRemoving(player)
end)

return FunnelService