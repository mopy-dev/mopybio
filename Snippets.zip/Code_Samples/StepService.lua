local StepService = {}

local Players = game:GetService("Players")

local DataManager = require(
	game.ServerScriptService:WaitForChild("DataStoreService"):WaitForChild("DataManager")
)
local TrailsModule = require(game.ServerScriptService:WaitForChild("TrailsModule"))
local SkinsModule = require(game.ServerScriptService:WaitForChild("SkinsModule"))
local MutationModule = require(game.ServerScriptService:WaitForChild("MutationModule"))
local EnchantService = require(game.ServerScriptService:WaitForChild("EnchantService"))
local VfxService = require(game.ServerScriptService:WaitForChild("VfxService"))
local FRIEND_BONUS_ATTR = "FriendBonusPercent"
local FRIEND_BONUS_PER_FRIEND = 10
local FRIEND_REFRESH_INTERVAL = 20

local active: {[Model]: boolean} = {}
local automatic: {[Player]: number} = {}
local friendBonusPercent: {[Player]: number} = {}
local nextFriendRefreshAt: {[Player]: number} = {}

local function countInServerFriends(player: Player): number
	local count = 0
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= player then
			local ok, isFriend = pcall(function()
				return player:IsFriendsWith(other.UserId)
			end)
			if ok and isFriend then
				count += 1
			end
		end
	end
	return count
end

local function refreshFriendBonus(player: Player, force: boolean?): number
	if not player or player.Parent ~= Players then
		return 0
	end

	local now = os.clock()
	if not force and now < (nextFriendRefreshAt[player] or 0) then
		return friendBonusPercent[player] or 0
	end

	nextFriendRefreshAt[player] = now + FRIEND_REFRESH_INTERVAL
	local percent = countInServerFriends(player) * FRIEND_BONUS_PER_FRIEND
	friendBonusPercent[player] = percent
	player:SetAttribute(FRIEND_BONUS_ATTR, percent)
	return percent
end

local function refreshAllFriendBonuses(force: boolean?)
	for _, plr in ipairs(Players:GetPlayers()) do
		refreshFriendBonus(plr, force)
	end
end

local function calculateGain(player: Player, base: number): number
	local value = tonumber(base) or 1
	local skinMult = SkinsModule.GetEquippedSkinMultiplier(player)
	local stepMult = skinMult or DataManager.GetStepMult(player) or 1
	local paidMult = DataManager.GetBoughtMults(player) or 1
	local trailMult = TrailsModule.GetEquippedTrailMultiplier(player) or 1
	local friendPercent = refreshFriendBonus(player, false)
	local friendMult = 1 + (math.max(0, friendPercent) / 100)
	local rebirthMult = DataManager.GetRebirthMult(player) or 1
	local mutationMult = MutationModule.GetSpeedMultiplier() or 1
	local enchantMult = EnchantService.GetMultiplier(player) or 1
	local total = value * stepMult * paidMult * trailMult * friendMult * rebirthMult * mutationMult * enchantMult
	total = math.floor(total + 0.5)
	if total < 1 then
		total = 1
	end
	return total
end

function StepService.Start(character: Model)
	local humanoid = character:WaitForChild("Humanoid")
	local player = Players:GetPlayerFromCharacter(character)
	if not player then
		return
	end

	local onoff = player:FindFirstChild("onoff")
	if not onoff then
		onoff = Instance.new("BoolValue")
		onoff.Name = "onoff"
		onoff.Value = false
		onoff.Parent = player
	end

	if active[character] then
		return
	end
	active[character] = true

	task.spawn(function()
		while active[character] and humanoid.Health > 0 do
			task.wait(0.8)
			refreshFriendBonus(player, false)

			if onoff.Value then
				local autoBase = automatic[player] or 1
				local gain = calculateGain(player, autoBase)
				DataManager.ProcessXP(player, gain, "step")
				VfxService.PlaySound(player, "BubbleSound")
			elseif humanoid.MoveDirection.Magnitude > 0 then
				local gain = calculateGain(player, 1)
				DataManager.ProcessXP(player, gain, "step")
				VfxService.PlaySound(player, "BubbleSound")
			end
		end
	end)
end

function StepService.Stop(character: Model)
	active[character] = nil
end

function StepService.ToggleAutomatic(player: Player, enabled: boolean | number, multiplier: number?)
	local onoff = player:FindFirstChild("onoff")
	if not onoff then
		return
	end

	if type(enabled) == "boolean" then
		onoff.Value = enabled
		if enabled then
			automatic[player] = tonumber(multiplier) or 1
		else
			automatic[player] = nil
		end
		return
	end

	onoff.Value = not onoff.Value
	automatic[player] = tonumber(enabled) or 1
end

Players.PlayerAdded:Connect(function(player)
	friendBonusPercent[player] = 0
	nextFriendRefreshAt[player] = 0
	player:SetAttribute(FRIEND_BONUS_ATTR, 0)

	player.CharacterAdded:Connect(function(character)
		StepService.Start(character)
	end)

	player.CharacterRemoving:Connect(function(character)
		StepService.Stop(character)
	end)

	task.defer(function()
		refreshAllFriendBonuses(true)
	end)
end)

Players.PlayerRemoving:Connect(function(player)
	automatic[player] = nil
	friendBonusPercent[player] = nil
	nextFriendRefreshAt[player] = nil

	task.defer(function()
		refreshAllFriendBonuses(true)
	end)
end)

task.spawn(function()
	while true do
		task.wait(FRIEND_REFRESH_INTERVAL)
		refreshAllFriendBonuses(true)
	end
end)

return StepService