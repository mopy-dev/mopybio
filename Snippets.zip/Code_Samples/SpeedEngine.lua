local SpeedEngine = {}

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Toaster = require(game.ServerScriptService:WaitForChild("Toaster"))
local Abbrev = require(ReplicatedStorage:WaitForChild("Libraries"):WaitForChild("Abbv_Module"))

local function getOrCreateFolder(parent: Instance, name: string): Folder
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local function getOrCreateMaxSpeedRemote(): RemoteEvent
	local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
	local customSpeed = getOrCreateFolder(remoteEvents, "CustomSpeed")

	local remote = customSpeed:FindFirstChild("MaxSpeed")
	if remote and not remote:IsA("RemoteEvent") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = "MaxSpeed"
		remote.Parent = customSpeed
	end

	return remote
end

local MaxSpeed = getOrCreateMaxSpeedRemote()

local PlayerLevels: {[Player]: number} = {}
local TemporaryBoosts: {[Player]: {multiplier: number, expiresAt: number}} = {}
local RequestedSpeed: {[Player]: number} = {}
local bonusAttributeConnections: {[Player]: RBXScriptConnection} = {}
local COIL_WALK_SPEED_BONUS_ATTR = "CoilWalkSpeedBonus"
local function formatNumber(value: number): string
	local n = math.max(0, math.floor(tonumber(value) or 0))
	local ok, out = pcall(function()
		return Abbrev.abbvNum(n)
	end)
	if ok and out ~= nil then
		return tostring(out)
	end
	return tostring(n)
end

local function getHumanoid(player: Player)
	local character = player.Character
	if not character then
		return nil
	end
	return character:FindFirstChildOfClass("Humanoid")
end

local function getCoilSpeedBonus(player: Player): number
	local bonus = math.floor(tonumber(player:GetAttribute(COIL_WALK_SPEED_BONUS_ATTR)) or 0)
	if bonus < 0 then
		bonus = 0
	end
	return bonus
end

local function getBaseMaxSpeed(level: number): number
	level = tonumber(level) or 1
	if level < 1 then
		level = 1
	end
	return math.floor(level * 2 + 14)
end

local function getActiveBoostMultiplier(player: Player): number
	local boost = TemporaryBoosts[player]
	if not boost then
		return 1
	end
	if os.clock() >= boost.expiresAt then
		TemporaryBoosts[player] = nil
		return 1
	end
	return math.max(1, tonumber(boost.multiplier) or 1)
end

local function hasActiveBoost(player: Player): boolean
	return getActiveBoostMultiplier(player) > 1
end

local function getEffectiveMaxSpeed(player: Player, level: number): number
	local base = getBaseMaxSpeed(level)
	local boosted = base * getActiveBoostMultiplier(player)
	return math.max(1, math.floor(boosted))
end

local function getAppliedWalkSpeed(player: Player, allowed: number): number
	allowed = math.max(1, math.floor(tonumber(allowed) or 1))
	if hasActiveBoost(player) then
		return allowed
	end

	local requested = RequestedSpeed[player]
	if requested == nil then
		return allowed
	end

	requested = math.floor(tonumber(requested) or allowed)
	if requested < 0 then
		requested = 0
	end
	if requested > allowed then
		requested = allowed
	end
	return requested
end

function SpeedEngine.GetAllowedMaxSpeed(level: number): number
	return getBaseMaxSpeed(level)
end

function SpeedEngine.UpdateSpeed(player: Player, level: number)
	level = tonumber(level) or 1
	if level < 1 then
		level = 1
	end

	PlayerLevels[player] = level
	local allowedWithoutBonus = getEffectiveMaxSpeed(player, level)
	local bonus = getCoilSpeedBonus(player)
	local allowed = allowedWithoutBonus + bonus
	MaxSpeed:FireClient(player, allowed)

	local humanoid = getHumanoid(player)
	if humanoid then
		humanoid.WalkSpeed = getAppliedWalkSpeed(player, allowedWithoutBonus) + bonus
	end
end
function SpeedEngine.RefreshPlayerSpeed(player: Player)
	if not player or player.Parent ~= Players then
		return
	end
	SpeedEngine.UpdateSpeed(player, PlayerLevels[player] or 1)
end

function SpeedEngine.ApplyTemporarySpeedBoost(player: Player, multiplier: number, durationSeconds: number)
	if not player or player.Parent ~= Players then
		return
	end

	multiplier = tonumber(multiplier) or 2
	durationSeconds = tonumber(durationSeconds) or 5
	if multiplier < 1 then
		multiplier = 1
	end
	if durationSeconds <= 0 then
		return
	end

	local now = os.clock()
	local existing = TemporaryBoosts[player]
	local expiresAt = now + durationSeconds
	if existing and existing.expiresAt > expiresAt then
		expiresAt = existing.expiresAt
	end

	TemporaryBoosts[player] = {
		multiplier = math.max(multiplier, existing and existing.multiplier or 1),
		expiresAt = expiresAt,
	}

	SpeedEngine.UpdateSpeed(player, PlayerLevels[player] or 1)

	task.spawn(function()
		task.wait(durationSeconds + 0.1)
		local current = TemporaryBoosts[player]
		if current and os.clock() >= current.expiresAt then
			TemporaryBoosts[player] = nil
			SpeedEngine.UpdateSpeed(player, PlayerLevels[player] or 1)
		end
	end)
end

Players.PlayerAdded:Connect(function(player)
	PlayerLevels[player] = 1
	bonusAttributeConnections[player] = player:GetAttributeChangedSignal(COIL_WALK_SPEED_BONUS_ATTR):Connect(function()
		SpeedEngine.RefreshPlayerSpeed(player)
	end)
end)

Players.PlayerRemoving:Connect(function(player)
	PlayerLevels[player] = nil
	TemporaryBoosts[player] = nil
	RequestedSpeed[player] = nil
	local connection = bonusAttributeConnections[player]
	if connection then
		connection:Disconnect()
		bonusAttributeConnections[player] = nil
	end
end)

MaxSpeed.OnServerEvent:Connect(function(player: Player, requestedSpeed: any)
	local level = PlayerLevels[player] or 1
	local allowedWithoutBonus = getEffectiveMaxSpeed(player, level)
	local bonus = getCoilSpeedBonus(player)
	local allowed = allowedWithoutBonus + bonus

	local parsed = tonumber(requestedSpeed)
	if not parsed then
		Toaster.AddToast(player, "Invalid number for speed.", Color3.fromRGB(255, 100, 100))
		MaxSpeed:FireClient(player, allowed)
		return
	end

	parsed = math.floor(parsed)
	if parsed < 0 then
		Toaster.AddToast(player, "Speed cannot be negative.", Color3.fromRGB(255, 100, 100))
		MaxSpeed:FireClient(player, allowed)
		return
	end

	if parsed > allowed then
		Toaster.AddToast(player, ("Failed: max speed is %s."):format(formatNumber(allowed)), Color3.fromRGB(255, 170, 0))
		MaxSpeed:FireClient(player, allowed)
		return
	end

	local humanoid = getHumanoid(player)
	if not humanoid then
		Toaster.AddToast(player, "Failed to set speed. Character not ready.", Color3.fromRGB(255, 100, 100))
		MaxSpeed:FireClient(player, allowed)
		return
	end

	local requestedWithoutBonus = parsed - bonus
	if requestedWithoutBonus < 0 then
		requestedWithoutBonus = 0
	elseif requestedWithoutBonus > allowedWithoutBonus then
		requestedWithoutBonus = allowedWithoutBonus
	end

	RequestedSpeed[player] = requestedWithoutBonus
	humanoid.WalkSpeed = requestedWithoutBonus + bonus
	Toaster.AddToast(player, ("Speed set to %s."):format(formatNumber(parsed)), Color3.fromRGB(100, 255, 100))
	MaxSpeed:FireClient(player, allowed)
end)

return SpeedEngine