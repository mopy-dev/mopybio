local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local remoteEvents = ReplicatedStorage:WaitForChild("RemoteEvents")
local analyticsFolder = remoteEvents:WaitForChild("Analytics")
local trackEventRemote = analyticsFolder:WaitForChild("TrackEvent")

local refs = {}
local boundButtons = setmetatable({}, { __mode = "k" })
local boundShopDescendantListener = nil
local boundShopScrollListener = nil
local lastCanvasPosition = nil
local sentShopScrolled = false

local SCROLL_THRESHOLD = 8

local function sendEvent(eventName: string, payload: {[string]: any}?)
	pcall(function()
		trackEventRemote:FireServer(eventName, payload or {})
	end)
end

local function resolveRefs(): boolean
	local playerGui = player:FindFirstChild("PlayerGui") or player:WaitForChild("PlayerGui")
	local mainUI = playerGui:FindFirstChild("MainUI")
	if not mainUI then
		return false
	end

	local leftMid = mainUI:FindFirstChild("LeftMid")
	local buttonsFrame = leftMid and leftMid:FindFirstChild("ButtonsFrame")
	local inner = buttonsFrame and buttonsFrame:FindFirstChild("Frame")
	local shopButton = inner and inner:FindFirstChild("Shop")

	local frames = mainUI:FindFirstChild("Frames")
	local shopFrame = frames and frames:FindFirstChild("Shop")
	local shopCanvas = shopFrame and shopFrame:FindFirstChild("CanvasGroup")
	local shopScrolling = (shopCanvas and shopCanvas:FindFirstChild("ScrollingFrame")) or (shopFrame and shopFrame:FindFirstChild("ScrollingFrame"))

	refs.shopButton = shopButton
	refs.shopFrame = shopFrame
	refs.shopScrolling = shopScrolling

	return true
end

local function isShopVisible(): boolean
	if not refs.shopFrame or not refs.shopFrame:IsA("GuiObject") then
		return false
	end
	return refs.shopFrame.Visible == true
end

local function getButtonProductId(button: Instance): number?
	if not button or not button:IsA("GuiObject") then
		return nil
	end

	local productValue = button:FindFirstChild("ProductID")
	if productValue and productValue:IsA("IntValue") then
		return productValue.Value
	end

	local passValue = button:FindFirstChild("PassID")
	if passValue and passValue:IsA("IntValue") then
		return passValue.Value
	end

	return nil
end

local function isBuyButton(button: Instance): boolean
	if not button or not button:IsA("GuiButton") then
		return false
	end
	if getButtonProductId(button) then
		return true
	end

	local lowerName = string.lower(button.Name)
	return lowerName == "buy" or string.sub(lowerName, 1, 3) == "buy"
end

local function bindBuyButton(button: GuiButton)
	if boundButtons[button] then
		return
	end
	boundButtons[button] = true

	button.Activated:Connect(function()
		if not resolveRefs() then
			return
		end
		if not refs.shopScrolling or not refs.shopScrolling:IsA("ScrollingFrame") then
			return
		end
		if not button:IsDescendantOf(refs.shopScrolling) then
			return
		end
		if not isBuyButton(button) then
			return
		end

		sendEvent("shop_buy_clicked", {
			productId = getButtonProductId(button),
			buttonName = button.Name,
		})
	end)
end

local function scanShopButtons()
	if not refs.shopScrolling or not refs.shopScrolling:IsA("ScrollingFrame") then
		return
	end
	for _, descendant in ipairs(refs.shopScrolling:GetDescendants()) do
		if descendant:IsA("GuiButton") and isBuyButton(descendant) then
			bindBuyButton(descendant)
		end
	end
end

local function bindShopEvents()
	if not resolveRefs() then
		return
	end

	if refs.shopButton and refs.shopButton:IsA("GuiButton") and not boundButtons[refs.shopButton] then
		boundButtons[refs.shopButton] = true
		refs.shopButton.Activated:Connect(function()
			sentShopScrolled = false
			lastCanvasPosition = nil
			sendEvent("shop_clicked")
		end)
	end

	if refs.shopScrolling and refs.shopScrolling:IsA("ScrollingFrame") then
		if boundShopScrollListener == nil then
			boundShopScrollListener = refs.shopScrolling:GetPropertyChangedSignal("CanvasPosition"):Connect(function()
				if not isShopVisible() then
					sentShopScrolled = false
					lastCanvasPosition = refs.shopScrolling.CanvasPosition
					return
				end

				local current = refs.shopScrolling.CanvasPosition
				if not lastCanvasPosition then
					lastCanvasPosition = current
					return
				end

				local delta = (current - lastCanvasPosition).Magnitude
				lastCanvasPosition = current
				if not sentShopScrolled and delta >= SCROLL_THRESHOLD then
					sentShopScrolled = true
					sendEvent("shop_scrolled")
				end
			end)
		end

		if boundShopDescendantListener == nil then
			boundShopDescendantListener = refs.shopScrolling.DescendantAdded:Connect(function(descendant)
				if descendant:IsA("GuiButton") and isBuyButton(descendant) then
					bindBuyButton(descendant)
				end
			end)
		end

		scanShopButtons()
	end
end

player.CharacterAdded:Connect(function()
	task.wait(0.4)
	bindShopEvents()
end)

task.spawn(function()
	while true do
		bindShopEvents()
		task.wait(0.5)
	end
end)

bindShopEvents()