local OfflineChestService = {}

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local DataManager = require(ServerScriptService:WaitForChild("DataStoreService"):WaitForChild("DataManager"))
local TrailsModule = require(ServerScriptService:WaitForChild("TrailsModule"))
local SkinsModule = require(ServerScriptService:WaitForChild("SkinsModule"))

local OFFLINE_PERCENT = 0.20
local OFFLINE_CAP_SECONDS = 10 * 60 * 60
local CLAIM_DELAY_SECONDS = 15 * 60
local STEP_INTERVAL_SECONDS = 0.3

local claimReadyAt: {[Player]: number} = {}

local function getOrCreateFolder(parent: Instance, name: string): Folder
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local function getOrCreateRemoteFunction(parent: Instance, name: string): RemoteFunction
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteFunction") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteFunction")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local function getOrCreateRemoteEvent(parent: Instance, name: string): RemoteEvent
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteEvent") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
local offlineFolder = getOrCreateFolder(remoteEvents, "OfflineChest")
local uiFolder = getOrCreateFolder(remoteEvents, "UI")

local getStateRemote = getOrCreateRemoteFunction(offlineFolder, "GetState")
local claimRemote = getOrCreateRemoteFunction(offlineFolder, "Claim")
local confettiRemote = getOrCreateRemoteEvent(uiFolder, "Confetti")

local function getProfile(player: Player)
	local profile = DataManager.Profiles[player]
	if not profile or not profile.Data then
		return nil
	end
	return profile
end

local function normalizeOfflineData(profile)
	local data = profile.Data
	data.PendingOfflineSeconds = math.max(0, math.floor(tonumber(data.PendingOfflineSeconds) or 0))
	data.PendingOfflineReward = math.max(0, math.floor(tonumber(data.PendingOfflineReward) or 0))
	data.LastLogoutTime = math.floor(tonumber(data.LastLogoutTime) or 0)

	if data.PendingOfflineReward <= 0 then
		data.PendingOfflineReward = 0
		data.PendingOfflineSeconds = 0
	end
end

local function estimateOnlineGainPerTick(player: Player): number
	local skinMult = SkinsModule.GetEquippedSkinMultiplier(player)
	local stepMult = skinMult or DataManager.GetStepMult(player) or 1
	local paidMult = DataManager.GetBoughtMults(player) or 1
	local trailMult = TrailsModule.GetEquippedTrailMultiplier(player) or 1

	local gain = stepMult * paidMult * trailMult
	gain = math.max(1, math.floor(gain + 0.5))
	return gain
end

local function computeOfflineReward(player: Player, offlineSeconds: number): number
	offlineSeconds = math.max(0, math.floor(tonumber(offlineSeconds) or 0))
	if offlineSeconds <= 0 then
		return 0
	end

	local gainPerTick = estimateOnlineGainPerTick(player)
	local gainPerSecond = gainPerTick / STEP_INTERVAL_SECONDS
	local reward = math.floor(gainPerSecond * offlineSeconds * OFFLINE_PERCENT)
	return math.max(0, reward)
end

local function setClaimTimer(player: Player, profile)
	normalizeOfflineData(profile)
	if profile.Data.PendingOfflineReward > 0 then
		claimReadyAt[player] = os.time() + CLAIM_DELAY_SECONDS
	else
		claimReadyAt[player] = nil
	end
end

local function tryAccrueOfflineReward(player: Player, profile)
	normalizeOfflineData(profile)
	local data = profile.Data

	if data.PendingOfflineReward > 0 then
		data.LastLogoutTime = 0
		return
	end

	if data.LastLogoutTime <= 0 then
		return
	end

	local now = os.time()
	local elapsed = math.max(0, now - data.LastLogoutTime)
	data.LastLogoutTime = 0

	if elapsed <= 0 then
		return
	end

	local cappedSeconds = math.min(OFFLINE_CAP_SECONDS, elapsed)
	local reward = computeOfflineReward(player, cappedSeconds)
	if reward <= 0 then
		return
	end

	data.PendingOfflineSeconds = cappedSeconds
	data.PendingOfflineReward = reward
end

local function buildState(player: Player, profile)
	normalizeOfflineData(profile)
	local data = profile.Data
	local now = os.time()
	local hasReward = data.PendingOfflineReward > 0
	local readyAt = claimReadyAt[player] or (now + CLAIM_DELAY_SECONDS)
	if hasReward and claimReadyAt[player] == nil then
		claimReadyAt[player] = readyAt
	end

	local claimRemaining = 0
	if hasReward then
		claimRemaining = math.max(0, readyAt - now)
	end

	return {
		hasReward = hasReward,
		offlineSeconds = math.max(0, data.PendingOfflineSeconds),
		rewardAmount = math.max(0, data.PendingOfflineReward),
		claimRemaining = claimRemaining,
		claimDelaySeconds = CLAIM_DELAY_SECONDS,
		ready = hasReward and claimRemaining <= 0,
		serverTime = now,
	}
end

local function initPlayer(player: Player)
	task.spawn(function()
		local profile = DataManager.WaitForProfileLoad(player)
		if not profile or not profile.Data then
			return
		end
		tryAccrueOfflineReward(player, profile)
		setClaimTimer(player, profile)
	end)
end

getStateRemote.OnServerInvoke = function(player: Player)
	if not player or player.Parent ~= Players then
		return {
			hasReward = false,
			offlineSeconds = 0,
			rewardAmount = 0,
			claimRemaining = 0,
			claimDelaySeconds = CLAIM_DELAY_SECONDS,
			ready = false,
			serverTime = os.time(),
		}
	end

	local profile = getProfile(player)
	if not profile then
		return {
			hasReward = false,
			offlineSeconds = 0,
			rewardAmount = 0,
			claimRemaining = CLAIM_DELAY_SECONDS,
			claimDelaySeconds = CLAIM_DELAY_SECONDS,
			ready = false,
			serverTime = os.time(),
		}
	end

	return buildState(player, profile)
end

claimRemote.OnServerInvoke = function(player: Player)
	if not player or player.Parent ~= Players then
		return {
			ok = false,
			code = "invalid_player",
		}
	end

	local profile = getProfile(player)
	if not profile then
		return {
			ok = false,
			code = "profile_not_loaded",
		}
	end

	local state = buildState(player, profile)
	if not state.hasReward then
		return {
			ok = false,
			code = "no_reward",
			state = state,
		}
	end

	if state.claimRemaining > 0 then
		return {
			ok = false,
			code = "not_ready",
			state = state,
		}
	end

	local amount = math.max(0, math.floor(tonumber(profile.Data.PendingOfflineReward) or 0))
	profile.Data.PendingOfflineReward = 0
	profile.Data.PendingOfflineSeconds = 0
	claimReadyAt[player] = nil

	if amount > 0 then
		DataManager.ProcessXP(player, amount, "reward")
		confettiRemote:FireClient(player, {})
	end

	return {
		ok = true,
		code = "claimed",
		claimedAmount = amount,
		state = buildState(player, profile),
	}
end

function OfflineChestService.GrantSimulatedTraining(player: Player, seconds: number, applyNerf: boolean?): number
	if not player or player.Parent ~= Players then
		return 0
	end

	local profile = getProfile(player)
	if not profile then
		return 0
	end

	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	if seconds <= 0 then
		return 0
	end

	local gainPerTick = estimateOnlineGainPerTick(player)
	local gainPerSecond = gainPerTick / STEP_INTERVAL_SECONDS
	local percent = OFFLINE_PERCENT
	if applyNerf == false then
		percent = 1
	end

	local amount = math.max(0, math.floor(gainPerSecond * seconds * percent))
	if amount > 0 then
		DataManager.ProcessXP(player, amount, "reward")
	end

	return amount
end

Players.PlayerAdded:Connect(initPlayer)
for _, player in ipairs(Players:GetPlayers()) do
	initPlayer(player)
end

Players.PlayerRemoving:Connect(function(player)
	claimReadyAt[player] = nil
	local profile = getProfile(player)
	if profile and profile.Data then
		profile.Data.LastLogoutTime = os.time()
	end
end)

return OfflineChestService