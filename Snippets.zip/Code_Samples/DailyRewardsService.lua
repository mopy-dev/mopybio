local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local Config = require(script:WaitForChild("Config"))
local DataManager = require(ServerScriptService:WaitForChild("DataStoreService"):WaitForChild("DataManager"))
local Toaster = require(ServerScriptService:WaitForChild("Toaster"))
local VfxService = require(ServerScriptService:WaitForChild("VfxService"))
local TrailsModule = require(ServerScriptService:WaitForChild("TrailsModule"))
local SkinsModule = require(ServerScriptService:WaitForChild("SkinsModule"))
local FunnelService = require(ServerScriptService:WaitForChild("FunnelService"))

local DAY_COUNT = 7

local firstPlaySession: {[Player]: boolean} = {}

local function getOrCreateFolder(parent: Instance, name: string): Folder
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local function getOrCreateRemoteFunction(parent: Instance, name: string): RemoteFunction
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteFunction") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteFunction")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local function getOrCreateRemoteEvent(parent: Instance, name: string): RemoteEvent
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteEvent") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
local dailyFolder = getOrCreateFolder(remoteEvents, "DailyRewards")
local uiFolder = getOrCreateFolder(remoteEvents, "UI")

local getStateRemote = getOrCreateRemoteFunction(dailyFolder, "GetState")
local claimDayRemote = getOrCreateRemoteFunction(dailyFolder, "ClaimDay")
local confettiRemote = getOrCreateRemoteEvent(uiFolder, "Confetti")

local DAY_INTERVAL = math.max(1, math.floor(tonumber(Config.DayIntervalSeconds) or (24 * 60 * 60)))
local MAX_PENDING = math.max(1, math.floor(tonumber(Config.MaxPendingClaims) or 14))

local function getProfile(player: Player)
	local profile = DataManager.Profiles[player]
	if not profile or not profile.Data then
		return nil
	end
	return profile
end

local function clampDay(day: number): number
	day = math.floor(tonumber(day) or 1)
	if day < 1 then
		return 1
	end
	if day > DAY_COUNT then
		return DAY_COUNT
	end
	return day
end

local function normalizeDailyData(profile)
	local data = profile.Data
	if type(data.DailyRewards) ~= "table" then
		data.DailyRewards = {}
	end

	local daily = data.DailyRewards
	daily.CurrentDay = clampDay(daily.CurrentDay)
	daily.PendingClaims = math.max(0, math.floor(tonumber(daily.PendingClaims) or 1))
	daily.LastAccrualTime = math.floor(tonumber(daily.LastAccrualTime) or 0)

	if daily.LastAccrualTime <= 0 then
		daily.LastAccrualTime = os.time()
	end

	return daily
end

local function accrueDaily(profile)
	local daily = normalizeDailyData(profile)
	local now = os.time()

	if daily.LastAccrualTime > now then
		daily.LastAccrualTime = now
	end

	local elapsed = now - daily.LastAccrualTime
	if elapsed >= DAY_INTERVAL then
		local gained = math.floor(elapsed / DAY_INTERVAL)
		if gained > 0 then
			daily.PendingClaims = math.min(MAX_PENDING, daily.PendingClaims + gained)
			daily.LastAccrualTime = daily.LastAccrualTime + (gained * DAY_INTERVAL)
		end
	end

	return daily, now
end

local function computeFirstPlaySession(profile, wins: number): boolean
	local hasLoggedOutBefore = math.floor(tonumber(profile.Data.LastLogoutTime) or 0) > 0

	if not hasLoggedOutBefore and wins <= 0 and profile.Data.DailyFirstPlayConsumed == true then
		-- Migration safety for players marked consumed before first win.
		profile.Data.DailyFirstPlayConsumed = false
	end

	if profile.Data.DailyFirstPlayConsumed == nil then
		profile.Data.DailyFirstPlayConsumed = hasLoggedOutBefore or wins > 0
	end

	if hasLoggedOutBefore then
		profile.Data.DailyFirstPlayConsumed = true
		return false
	end

	if wins > 0 then
		profile.Data.DailyFirstPlayConsumed = true
		return false
	end

	return profile.Data.DailyFirstPlayConsumed ~= true
end

local function buildState(player: Player, profile)
	local daily, now = accrueDaily(profile)
	local currentDay = clampDay(daily.CurrentDay)
	local pendingClaims = math.max(0, math.floor(tonumber(daily.PendingClaims) or 0))
	local secondsToNext = math.max(0, DAY_INTERVAL - (now - daily.LastAccrualTime))
	local tutorialCompleted = profile.Data.TutorialCompleted == true
	local wins = math.max(0, math.floor(tonumber(profile.Data.Wins) or 0))

	local isFirstPlaySession = computeFirstPlaySession(profile, wins)
	firstPlaySession[player] = isFirstPlaySession

	local days = {}
	for day = 1, DAY_COUNT do
		local rewardData = Config.Rewards[day] or {}
		local claimed = day < currentDay
		local ready = day == currentDay and pendingClaims > 0
		local secondsToReady = 0

		if not claimed and not ready then
			local tokensNeeded = (day - currentDay) + 1
			local tokensShort = math.max(0, tokensNeeded - pendingClaims)
			if tokensShort > 0 then
				secondsToReady = secondsToNext + ((tokensShort - 1) * DAY_INTERVAL)
			end
		end

		days[day] = {
			day = day,
			description = tostring(rewardData.Description or ""),
			imageId = tostring(rewardData.ImageId or ""),
			showRays = rewardData.ShowRays == true,
			claimed = claimed,
			ready = ready,
			secondsToReady = secondsToReady,
		}
	end

	return {
		serverTime = now,
		currentDay = currentDay,
		pendingClaims = pendingClaims,
		secondsToNext = secondsToNext,
		wins = wins,
		tutorialCompleted = tutorialCompleted,
		firstPlaySession = isFirstPlaySession,
		days = days,
	}
end

local function grantReward(player: Player, profile, reward)
	if type(reward) ~= "table" then
		return
	end

	local speed = math.max(0, math.floor(tonumber(reward.Speed) or 0))
	if speed > 0 then
		DataManager.ProcessXP(player, speed, "reward")
	end

	local wins = math.max(0, math.floor(tonumber(reward.Wins) or 0))
	if wins > 0 then
		DataManager.AddRawWins(player, wins)
	end

	local trailName = reward.Trail
	if type(trailName) == "string" and trailName ~= "" then
		TrailsModule.UnlockAndEquipTrail(player, trailName, false, false)
	end

	local skinName = reward.Skin
	if type(skinName) == "string" and skinName ~= "" then
		SkinsModule.GrantSkin(player, skinName, 1, false, false)
	end

	local rebirths = math.max(0, math.floor(tonumber(reward.Rebirths) or 0))
	if rebirths > 0 then
		profile.Data.Rebirths = math.max(0, math.floor(tonumber(profile.Data.Rebirths) or 0) + rebirths)
		FunnelService.TrackRebirthProgress(player, profile.Data.Rebirths, profile)
		DataManager.PushProgress(player)
	end
end

local function claimDay(player: Player, requestedDay: number?)
	local profile = getProfile(player)
	if not profile then
		return {
			ok = false,
			code = "profile_not_loaded",
		}
	end

	local daily = normalizeDailyData(profile)
	accrueDaily(profile)
	daily = normalizeDailyData(profile)

	local currentDay = clampDay(daily.CurrentDay)
	local pendingClaims = math.max(0, math.floor(tonumber(daily.PendingClaims) or 0))
	local targetDay = clampDay(tonumber(requestedDay) or currentDay)

	if targetDay < currentDay then
		return {
			ok = false,
			code = "already_claimed",
			state = buildState(player, profile),
		}
	end

	if pendingClaims <= 0 or targetDay ~= currentDay then
		if targetDay > 1 then
			Toaster.AddToast(player, "Not ready", Color3.fromRGB(255, 100, 100))
		end
		return {
			ok = false,
			code = "not_ready",
			state = buildState(player, profile),
		}
	end

	local rewardData = Config.Rewards[currentDay]
	if type(rewardData) == "table" then
		grantReward(player, profile, rewardData.Reward)
	end

	daily.PendingClaims = math.max(0, pendingClaims - 1)
	daily.CurrentDay = currentDay + 1
	if daily.CurrentDay > DAY_COUNT then
		daily.CurrentDay = 1
	end

	Toaster.AddToast(player, "Claimed!", Color3.fromRGB(120, 255, 120))
	VfxService.PlaySound(player, "ClaimSound")
	confettiRemote:FireClient(player, {})

	return {
		ok = true,
		code = "claimed",
		claimedDay = currentDay,
		state = buildState(player, profile),
	}
end

getStateRemote.OnServerInvoke = function(player: Player)
	if not player or player.Parent ~= Players then
		return nil
	end

	local profile = getProfile(player)
	if not profile then
		return nil
	end

	return buildState(player, profile)
end

claimDayRemote.OnServerInvoke = function(player: Player, requestedDay: number?)
	if not player or player.Parent ~= Players then
		return {
			ok = false,
			code = "invalid_player",
		}
	end

	return claimDay(player, requestedDay)
end

local function initPlayer(player: Player)
	task.spawn(function()
		local profile = DataManager.WaitForProfileLoad(player)
		if not profile or not profile.Data then
			return
		end

		local wins = math.max(0, math.floor(tonumber(profile.Data.Wins) or 0))
		firstPlaySession[player] = computeFirstPlaySession(profile, wins)
		accrueDaily(profile)
	end)
end

Players.PlayerAdded:Connect(initPlayer)
for _, player in ipairs(Players:GetPlayers()) do
	initPlayer(player)
end

Players.PlayerRemoving:Connect(function(player)
	firstPlaySession[player] = nil
end)