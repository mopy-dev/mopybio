local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local DataManager = require(game.ServerScriptService:WaitForChild("DataStoreService"):WaitForChild("DataManager"))
local FunnelService = require(game.ServerScriptService:WaitForChild("FunnelService"))
local CoilService = require(game.ServerScriptService:WaitForChild("Coil"):WaitForChild("CoilService"))
local PresentModule = require(game.ServerScriptService:WaitForChild("PresentModule"))

local REWARD_WINS = 5
local openedPresentsByPlayer = {}

local function getOrCreateFolder(parent, name)
	local folder = parent:FindFirstChild(name)
	if folder and not folder:IsA("Folder") then
		folder:Destroy()
		folder = nil
	end
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = name
		folder.Parent = parent
	end
	return folder
end

local function getOrCreateRemoteFunction(parent, name)
	local remote = parent:FindFirstChild(name)
	if remote and not remote:IsA("RemoteFunction") then
		remote:Destroy()
		remote = nil
	end
	if not remote then
		remote = Instance.new("RemoteFunction")
		remote.Name = name
		remote.Parent = parent
	end
	return remote
end

local remoteEvents = getOrCreateFolder(ReplicatedStorage, "RemoteEvents")
local firstLeaveFolder = getOrCreateFolder(remoteEvents, "FirstLeaveGift")
local claimRemote = getOrCreateRemoteFunction(firstLeaveFolder, "Claim")

local function getProfile(player)
	local profile = DataManager.Profiles[player]
	if not profile or not profile.Data then
		return nil
	end
	return profile
end

local function getClaimed(profile)
	if profile.Data.FirstLeaveGiftClaimed == nil then
		profile.Data.FirstLeaveGiftClaimed = false
	end
	return profile.Data.FirstLeaveGiftClaimed == true
end

local function spawnLeaveRewardPresents(player)
	local winsConfig = {
		wins = REWARD_WINS,
		toastOnCollect = "+5 Wins!",
		toastColor = Color3.fromRGB(120, 255, 120),
		playConfetti = true,
		playSound = "ClaimSound",
	}
	local coilConfig = {
		toastOnCollect = "Speed Coil Unlocked!",
		toastColor = Color3.fromRGB(120, 255, 120),
		playConfetti = true,
		playSound = "ClaimSound",
		onCollect = function(collector)
			CoilService.GrantLeaveReward(collector, 0)
		end,
	}

	local winsSpawned = PresentModule.SpawnRewardPresent(player, winsConfig)
	if not winsSpawned then
		PresentModule.GiveRewardNow(player, winsConfig)
	end

	local coilSpawned = PresentModule.SpawnRewardPresent(player, coilConfig)
	if not coilSpawned then
		PresentModule.GiveRewardNow(player, coilConfig)
	end
end

local function ensurePresentsSpawned(player)
	if openedPresentsByPlayer[player] == true then
		return
	end
	openedPresentsByPlayer[player] = true
	spawnLeaveRewardPresents(player)
end

local function onInvoke(player, action)
	if not player or player.Parent ~= Players then
		if action == "get" then
			return false
		end
		return { status = "error" }
	end

	local profile = getProfile(player)
	if not profile then
		if action == "get" then
			return false
		end
		return { status = "error" }
	end

	if action == "get" then
		return getClaimed(profile)
	end

	if action == "open" then
		if getClaimed(profile) then
			return { status = "already" }
		end
		ensurePresentsSpawned(player)
		return { status = "opened" }
	end

	if action ~= "claim" then
		return { status = "error" }
	end

	if getClaimed(profile) then
		return { status = "already" }
	end

	ensurePresentsSpawned(player)
	profile.Data.FirstLeaveGiftClaimed = true
	player:SetAttribute("FirstLeaveGiftClaimed", true)
	FunnelService.TrackLeaveRewardClaimed(player, profile)

	return { status = "claimed" }
end

claimRemote.OnServerInvoke = onInvoke

Players.PlayerRemoving:Connect(function(player)
	openedPresentsByPlayer[player] = nil
end)